#ifndef LU_H
#define LU_H

#include <math.h>
#include <iostream>
#define TINY 1.0e-20

static void ludcmp(double *a, int n, int *indx, double *d)
{
	int i, imax, j, k;
	double big, dum, sum, temp;
	double *vv;

	vv = new double[n];
	*d = 1.0;
	for (i = 1; i <= n; i++) {
		big = 0.0;
		for (j = 1; j <= n; j++)
			if ((temp = fabs(a[(i - 1)*n + j - 1])) > big) big = temp;
		if (big == 0.0)
		{
			std::cerr << "Error: singular matrix in routine ludcmp!" << std::endl;
			exit(1);
		}
		vv[i - 1] = 1.0 / big;
	}
	for (j = 1; j <= n; j++) {
		for (i = 1; i<j; i++) {
			sum = a[(i - 1)*n + j - 1];
			for (k = 1; k<i; k++) sum -= a[(i - 1)*n + k - 1] * a[(k - 1)*n + j - 1];
			a[(i - 1)*n + j - 1] = sum;
		}
		big = 0.0;
		for (i = j; i <= n; i++) {
			sum = a[(i - 1)*n + j - 1];
			for (k = 1; k<j; k++)
				sum -= a[(i - 1)*n + k - 1] * a[(k - 1)*n + j - 1];
			a[(i - 1)*n + j - 1] = sum;
			if ((dum = vv[i - 1] * fabs(sum)) >= big) {
				big = dum;
				imax = i;
			}
		}
		if (j != imax) {
			for (k = 1; k <= n; k++) {
				dum = a[(imax - 1)*n + k - 1];
				a[(imax - 1)*n + k - 1] = a[(j - 1)*n + k - 1];
				a[(j - 1)*n + k - 1] = dum;
			}
			*d = -(*d);
			vv[imax - 1] = vv[j - 1];
		}
		indx[j - 1] = imax;
		if (a[(j - 1)*n + j - 1] == 0.0) a[(j - 1)*n + j - 1] = TINY;
		if (j != n) {
			dum = 1.0 / (a[(j - 1)*n + j - 1]);
			for (i = j + 1; i <= n; i++) a[(i - 1)*n + j - 1] *= dum;
		}
	}
	delete[] vv;
}


static void lubksb(double *a, int n, int *indx, double b[])
{
	int i, ii = 0, ip, j;
	double sum;

	for (i = 1; i <= n; i++) {
		ip = indx[i - 1];
		sum = b[ip - 1];
		b[ip - 1] = b[i - 1];
		if (ii)
			for (j = ii; j <= i - 1; j++) sum -= a[(i - 1)*n + j - 1] * b[j - 1];
		else if (sum) ii = i;
		b[i - 1] = sum;
	}
	for (i = n; i >= 1; i--) {
		sum = b[i - 1];
		for (j = i + 1; j <= n; j++) sum -= a[(i - 1)*n + j - 1] * b[j - 1];
		b[i - 1] = sum / a[(i - 1)*n + i - 1];
	}
}

#undef TINY
#endif