/**********************************************************************
readOptions.h - Read parameters in Crystalpicker.in
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/

#ifndef READOPTION
#define READOPTION
//
#include <string>
#include <vector>

#ifdef _WIN32
#ifndef UNSIGNEDINT
#define UNSIGNEDINT
typedef unsigned int uint;
#endif
#endif

//
class readOptions{
private:
	std::vector<std::pair<std::pair<std::string, std::string>, double>> bondingPairs;
	std::vector<std::vector<std::pair<std::pair<std::string, std::string>, double>>> localBondingPairs;
	std::vector<std::pair<std::pair<std::string, std::string>, double>> minDistanceOfAtoms;
    bool m_optionsAreValid;
	std::string m_filename;
	std::string poscarFilename;
	std::string inputDir;
	std::string outputDir;
	int maxNumOfFilesForEachSpg;
	int maxNumOfOutputFilesForEachSpg;
	double defaultMinDistanceOfAtoms;
	int minNumberOfBonds;
	std::vector<int> minNumOfLocalBonds;
	int periodicalRange;
	std::vector<std::pair<std::pair<std::string, std::string>, int>> maxNumOfSharedVertexes;
	std::vector<std::string> forbiddenPyramidalPolyhedrons;
	std::vector<std::pair<std::string, double>> minVolumeOfPolyhedrons;
	std::vector<uint> spacegroups;
	std::vector<std::pair<std::string, int>> minCoordinationNumber;
	std::vector<std::pair<std::string, int>> maxCoordinationNumber;
	std::vector<std::pair<std::string, std::vector<std::pair<std::string, int>>>> maxNumOfAtomsOnPolyhedron;
	int maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg;
	int maxNumOfOutputFilesForEachSimilarStructureType;
	bool xtalComp;
	double lenTol, angleTol, posTol;
public:
    explicit readOptions();
    readOptions& operator=(const readOptions& s);
    readOptions(const readOptions& s);
	static readOptions readInput(const std::string& filename);
    static readOptions readOptionsFromCharArray(const char* input,
		                                        std::string filename = "");
	void interpretLineAndSetOption(std::string line);
    //string getOptionsString() const;
    bool optionsAreValid() const {return m_optionsAreValid;}
    //Getters
	std::vector<std::pair<std::pair<std::string, std::string>, double>> get_bondingPairs() const { return bondingPairs; }
	std::vector<std::vector<std::pair<std::pair<std::string, std::string>, double>>> get_localBondingPairs() const { return localBondingPairs; }
	std::vector<std::pair<std::pair<std::string, std::string>, double>> get_minDistanceOfAtoms() const { return minDistanceOfAtoms; }
	std::string get_filename() const { return m_filename; }
	std::string get_poscarFilename() const { return poscarFilename; }
	std::string get_inputDir() const { return inputDir; }
	std::string get_outputDir() const { return outputDir; }
	double get_defaultMinDistanceOfAtoms() const { return defaultMinDistanceOfAtoms; }
	int get_maxNumOfFilesForEachSpg() const { return maxNumOfFilesForEachSpg; }
	int get_maxNumOfOutputFilesForEachSpg() const { return maxNumOfOutputFilesForEachSpg; }
	int get_minNumberOfBonds() const { return minNumberOfBonds; }
	std::vector<int> get_minNumOfLocalBonds() const { return minNumOfLocalBonds; }
	int get_periodicalRange() const { return periodicalRange; }
	std::vector<std::pair<std::pair<std::string, std::string>, int>> get_maxNumOfSharedVertexes() const { return maxNumOfSharedVertexes; }
	std::vector<std::string> get_forbiddenPyramidalPolyhedrons() const { return forbiddenPyramidalPolyhedrons; }
	std::vector<std::pair<std::string, double>> get_minVolumeOfPolyhedrons() const { return minVolumeOfPolyhedrons; }
	std::vector<uint> getSpacegroups() const { return spacegroups; }
	std::vector<std::pair<std::string, int>> get_minCoordinationNumber() const { return minCoordinationNumber; }
	std::vector<std::pair<std::string, int>> get_maxCoordinationNumber() const { return maxCoordinationNumber; }
	std::vector<std::pair<std::string, std::vector<std::pair<std::string, int>>>> get_maxNumOfAtomsOnPolyhedron() const { return maxNumOfAtomsOnPolyhedron; }
	int get_maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg() const { return maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg; }
	int get_maxNumOfOutputFilesForEachSimilarStructureType() const { return maxNumOfOutputFilesForEachSimilarStructureType; }
	double get_lenTol() const { return lenTol; }
	double get_angleTol() const { return angleTol; }
	double get_posTol() const { return posTol; }
	bool get_xtalComp() const { return xtalComp; }
	// Setters
	void set_bondingPairs(const std::vector<std::pair<std::pair<std::string, std::string>, double>>& s) { bondingPairs = s; }
	void set_localBondingPairs(const std::vector<std::vector<std::pair<std::pair<std::string, std::string>, double>>>& s) { localBondingPairs = s; }
	void set_minDistanceOfAtoms(const std::vector<std::pair<std::pair<std::string, std::string>, double>>& s) { minDistanceOfAtoms = s; }
	void set_filename(const std::string& s) { m_filename = s; }
	void set_poscarFilename(const std::string& s) { poscarFilename = s; }
	void set_defaultMinDistanceOfAtoms(const double& var) { defaultMinDistanceOfAtoms = var; }
	void set_maxNumOfFilesForEachSpg(const int& var) { maxNumOfFilesForEachSpg = var; }
	void set_maxNumOfOutputFilesForEachSpg(const int& var) { maxNumOfOutputFilesForEachSpg = var; }
	void set_inputDir(const std::string& s) { inputDir = s; }
	void set_outputDir(const std::string& s) { outputDir = s; }
	void set_minNumberOfBonds(const int& var) { minNumberOfBonds = var; }
	void set_minNumOfLocalBonds(const std::vector<int>& var) { minNumOfLocalBonds = var; }
	void set_periodicalRange(const int& var) { periodicalRange = var; }
	void set_forbiddenPyramidalPolyhedrons(const std::vector<std::string>& var) { forbiddenPyramidalPolyhedrons = var; }
	void set_minVolumeOfPolyhedrons(const std::vector<std::pair<std::string, double>>& var) { minVolumeOfPolyhedrons = var; }
	void set_maxNumOfSharedVertexes(const std::vector<std::pair<std::pair<std::string, std::string>, int>>& var) { maxNumOfSharedVertexes = var; }
	void setSpacegroups(const std::vector<uint>& v) { spacegroups = v; };
	void set_minCoordinationNumber(const std::vector<std::pair<std::string, int>>& var) { minCoordinationNumber = var; }
	void set_maxCoordinationNumber(const std::vector<std::pair<std::string, int>>& var) { maxCoordinationNumber = var; }
	void set_maxNumOfAtomsOnPolyhedron(const std::vector<std::pair<std::string, std::vector<std::pair<std::string, int>>>>& var) { maxNumOfAtomsOnPolyhedron = var; }
	void set_maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg(const int& var) { maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg = var; }
	void set_maxNumOfOutputFilesForEachSimilarStructureType(const int& var) { maxNumOfOutputFilesForEachSimilarStructureType = var; }
	void set_lenTol(const double& var) { lenTol = var; }
	void set_angleTol(const double& var) { angleTol = var; }
	void set_posTol(const double& var) { posTol = var; }
	void set_xtalComp(const bool& var) { xtalComp = var; }
};
#endif
