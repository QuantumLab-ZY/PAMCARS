/**********************************************************************
readOptions.cpp - Read parameters in Crystalpicker.in
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/

#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include "utilityFunctions.h"
#include "readOptions.h"
//
using namespace std;

readOptions::readOptions():
	bondingPairs(vector<pair<pair<string, string>, double>>()),
	localBondingPairs(vector<vector<pair<pair<string, string>, double>>>()),
	minDistanceOfAtoms(vector<pair<pair<string, string>, double>>()),
    m_optionsAreValid(true),
	m_filename(""),
	poscarFilename(""),
	defaultMinDistanceOfAtoms(1.0),
	maxNumOfFilesForEachSpg(0),
	inputDir(""),
	maxNumOfOutputFilesForEachSpg(30),
	minNumberOfBonds(0),
	minNumOfLocalBonds(vector<int>()),
	periodicalRange(1),
	maxNumOfSharedVertexes(vector<pair<pair<string, string>, int>>()),
	outputDir(""),
	forbiddenPyramidalPolyhedrons(vector<string>()),
	minVolumeOfPolyhedrons(vector<pair<string, double>>()),
	spacegroups(vector<uint>()),
	minCoordinationNumber(vector<pair<string, int>>()),
	maxCoordinationNumber(vector<pair<string, int>>()),
	maxNumOfAtomsOnPolyhedron(std::vector<std::pair<std::string, std::vector<pair<std::string, int>>>>()),
	maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg(100),
	maxNumOfOutputFilesForEachSimilarStructureType(3),
	lenTol(1.0),
	angleTol(3.0),
	posTol(0.4),
	xtalComp(false)
{
}

readOptions::readOptions(const readOptions& s){
	bondingPairs = s.bondingPairs;
	localBondingPairs = s.localBondingPairs;
	minDistanceOfAtoms = s.minDistanceOfAtoms;
	defaultMinDistanceOfAtoms = s.defaultMinDistanceOfAtoms;
	m_optionsAreValid = s.m_optionsAreValid;
	m_filename = s.m_filename;
	poscarFilename = s.poscarFilename;
	maxNumOfFilesForEachSpg = s.maxNumOfFilesForEachSpg;
	inputDir = s.inputDir;
	outputDir = s.outputDir;
	maxNumOfOutputFilesForEachSpg = s.maxNumOfOutputFilesForEachSpg;
	minNumberOfBonds = s.minNumberOfBonds;
	minNumOfLocalBonds = s.minNumOfLocalBonds;
	periodicalRange = s.periodicalRange;
	maxNumOfSharedVertexes = s.maxNumOfSharedVertexes;
	forbiddenPyramidalPolyhedrons = s.forbiddenPyramidalPolyhedrons;
	minVolumeOfPolyhedrons = s.minVolumeOfPolyhedrons;
	spacegroups = s.spacegroups;
	minCoordinationNumber = s.minCoordinationNumber;
	maxCoordinationNumber = s.maxCoordinationNumber;
	maxNumOfAtomsOnPolyhedron = s.maxNumOfAtomsOnPolyhedron;
	maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg = s.maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg;
	maxNumOfOutputFilesForEachSimilarStructureType = s.maxNumOfOutputFilesForEachSimilarStructureType;
	lenTol = s.lenTol;
	angleTol = s.angleTol;
	posTol = s.posTol;
	xtalComp = s.xtalComp;
}


readOptions& readOptions::operator=(const readOptions& s){
    if(this!=&s){
		bondingPairs = s.bondingPairs;
		localBondingPairs = s.localBondingPairs;
		minDistanceOfAtoms = s.minDistanceOfAtoms;
		defaultMinDistanceOfAtoms = s.defaultMinDistanceOfAtoms;
		m_optionsAreValid = s.m_optionsAreValid;
		m_filename = s.m_filename;
		poscarFilename = s.poscarFilename;
		maxNumOfFilesForEachSpg = s.maxNumOfFilesForEachSpg;
		inputDir = s.inputDir;
		outputDir = s.outputDir;
		maxNumOfOutputFilesForEachSpg = s.maxNumOfOutputFilesForEachSpg;
		minNumberOfBonds = s.minNumberOfBonds;
		minNumOfLocalBonds = s.minNumOfLocalBonds;
		maxNumOfSharedVertexes = s.maxNumOfSharedVertexes;
		forbiddenPyramidalPolyhedrons = s.forbiddenPyramidalPolyhedrons;
		minVolumeOfPolyhedrons = s.minVolumeOfPolyhedrons;
		spacegroups = s.spacegroups;
		minCoordinationNumber = s.minCoordinationNumber;
		maxCoordinationNumber = s.maxCoordinationNumber;
		maxNumOfAtomsOnPolyhedron = s.maxNumOfAtomsOnPolyhedron;
		maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg = s.maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg;
		maxNumOfOutputFilesForEachSimilarStructureType = s.maxNumOfOutputFilesForEachSimilarStructureType;
		lenTol = s.lenTol;
		angleTol = s.angleTol;
		posTol = s.posTol;
		xtalComp = s.xtalComp;
    }
    return *this;
}



// This function is static
readOptions readOptions::readInput(const string& filename)
{
   readOptions options;
   ifstream f;
   f.open(filename);
   if (!f.is_open()) {
      cerr << "Error: " << filename << " was not opened successfully! Please "
      << "check the permissions and that it exists.\n";
      options.m_optionsAreValid = false;
      return options;
   }
// So that we avoid code duplication, read the contents of this file into
// a string and call the other function. We are assuming that
// the input file is going to be small so this should not cause any
// memory issues...
    string temp;
    string inputStr;
    while (getline(f, temp)) inputStr += (temp + "\n");
    f.close();
    return readOptionsFromCharArray(inputStr.c_str(), filename);
}

// This version of the function reads a character array that contains the full
// input. It is used for the html version of the code
readOptions readOptions::readOptionsFromCharArray(const char* input,
                                                  string filename)
{
    readOptions options;
    options.m_filename = filename;
    string stdstr(input);
    istringstream lines(stdstr);
    string line;
// Read each line and set options
    while (getline(lines, line)) options.interpretLineAndSetOption(line);
    return options;
}

vector<uint> createSpgVector(string s)
{
	vector<uint> ret;
	s = trim(s);
	s = removeSpacesAndReturns(s); // important for reading input from html
								   // Split it according to commas
	vector<string> ssplit = split(s, ',');
	for (size_t i = 0; i < ssplit.size(); i++) {
		// Add all individual numbers
		if (isNumber(trim(ssplit[i]))) ret.push_back(stoi(trim(ssplit[i])));
		// Add hyphenated numbers
		else if (contains(ssplit[i], '-')) {
			// Split it
			vector<string> hyphenSplit = split(ssplit[i], '-');
			if (hyphenSplit.size() != 2) {
				cerr << "Error understanding the spacegroups option. Please verify that"
					<< " it is properly formatted with commas and hyphens.\n";
				return ret;
			}
			// Find the first number, and keep adding numbers till we get to the final
			// one
			uint firstNum = stoi(trim(hyphenSplit[0]));
			uint lastNum = stoi(trim(hyphenSplit[1]));
			for (uint i = firstNum; i <= lastNum; i++) ret.push_back(i);
		}
	}
	// Sort the numbers
	sort(ret.begin(), ret.end());
	// Remove duplicates
	ret = removeDuplicates<uint>(ret);
	return ret;
}

void readOptions::interpretLineAndSetOption(string line)
{
    // First, trim it
    line = trim(line);
    // If the line is empty, return
    // If the line starts with '#', return
    if (line.size() == 0) return;
    if (line[0] == '#') return;
    // Remove anything to the right of any # in the line - this is a comment
    line = split(line, '#')[0];
    // Separate the option and the value
    vector<string> theSplit = split(line, '=');
    // If this is not two, then there is some kind of error in the line
    if (theSplit.size() != 2) {
       cerr << "In options files, '" << this->m_filename << "', error reading "
       << "the following line: '" << line << "'\n";
	   m_optionsAreValid = false;
       return;
    }
    string option = trim(theSplit[0]);
    string value = trim(theSplit[1]);
    // Now let's figure out what the option is

    if (option == "minDistanceOfAtoms") {
        vector<string> tempSplit = split(value, ',');
        pair<pair<string, string>,double> ssd;
        vector<string> tempString;
        for(int i=0;i<tempSplit.size();++i){
            tempSplit[i]=trim(tempSplit[i]);
            tempString=split(tempSplit[i], ':');
            ssd.first.first=trim(split(tempString[0],'-')[0]);
            ssd.first.second=trim(split(tempString[0],'-')[1]);
            ssd.second=stod(trim(tempString[1]));
            minDistanceOfAtoms.push_back(ssd);
        }
    }
	//
	else if (option == "globalBondingPairs") {
		vector<string> tempSplit = split(value, ',');
		pair<pair<string, string>, double> ssd;
		vector<string> tempString;
		for (int i = 0; i<tempSplit.size(); ++i){
			tempSplit[i] = trim(tempSplit[i]);
			tempString = split(tempSplit[i], ':');
			ssd.first.first = trim(split(tempString[0], '-')[0]);
			ssd.first.second = trim(split(tempString[0], '-')[1]);
			ssd.second = stod(trim(tempString[1]));
			bondingPairs.push_back(ssd);
		}
	}
	//
	else if (option == "localBondingPairs") {
		vector<string> bondingPairSplit = split(value, ';');
		for (size_t i = 0; i < bondingPairSplit.size(); i++)
		{
			vector<string> tempSplit = split(bondingPairSplit[i], ',');
			pair<pair<string, string>, double> ssd;
			vector<string> tempString;
			vector<pair<pair<string, string>, double>> tempBondingPair;
			for (int j = 0; j<tempSplit.size(); ++j) {
				tempSplit[j] = trim(tempSplit[j]);
				tempString = split(tempSplit[j], ':');
				ssd.first.first = trim(split(tempString[0], '-')[0]);
				ssd.first.second = trim(split(tempString[0], '-')[1]);
				ssd.second = stod(trim(tempString[1]));
				tempBondingPair.push_back(ssd);
			}//j
			localBondingPairs.push_back(tempBondingPair);
		}//i
	}
	//
    else if (option == "defaultMinDistanceOfAtoms") {
        defaultMinDistanceOfAtoms = stod(value);
    }
	else if (option == "poscarFilename") {
		poscarFilename = value;
	}
	else if (option == "spacegroups") {
		spacegroups = createSpgVector(value);
	}
	else if (option == "maxNumOfFilesForEachSpg") {
		maxNumOfFilesForEachSpg = stoi(value);
	}
	else if (option == "inputDir") {
		inputDir = value;
	}
	else if (option == "outputDir") {
		outputDir = value;
	}
	else if (option == "maxNumOfOutputFilesForEachSpg") {
		maxNumOfOutputFilesForEachSpg = stoi(value);
	}
	else if (option == "minNumOfGlobalBonds") {
		minNumberOfBonds = stoi(value);
	}
	else if (option == "minNumOfLocalBonds") {
		vector<string> tempSplit = split(value, ';');
		for (size_t i = 0; i < tempSplit.size(); i++)
		{
			tempSplit[i] = trim(tempSplit[i]);
			double d = stod(tempSplit[i]);
			minNumOfLocalBonds.push_back(d);
		}
	}
	else if (option == "forbiddenPyramidalPolyhedrons") {
		vector<string> tempSplit = split(value, ',');
		for (size_t i = 0; i < tempSplit.size(); i++)
		{
			tempSplit[i] = trim(tempSplit[i]);
			string d = tempSplit[i];
			forbiddenPyramidalPolyhedrons.push_back(d);
		}
	}
	else if (option == "minVolumeOfPolyhedrons") {
		vector<string> tempSplit = split(value, ',');
		vector<string> tempSplitSplit;
		for (int i = 0; i<tempSplit.size(); ++i) {
			pair<string, double> sd;
			tempSplit[i] = trim(tempSplit[i]);
			tempSplitSplit = split(tempSplit[i], ':');
			sd.first = trim(tempSplitSplit[0]);
			sd.second = stod(trim(tempSplitSplit[1]));
			minVolumeOfPolyhedrons.push_back(sd);
		}
	}
	else if (option == "minCoordinationNumber") {
		vector<string> tempSplit = split(value, ',');
		vector<string> tempSplitSplit;
		for (int i = 0; i<tempSplit.size(); ++i) {
			pair<string, int> sd;
			tempSplit[i] = trim(tempSplit[i]);
			tempSplitSplit = split(tempSplit[i], ':');
			sd.first = trim(tempSplitSplit[0]);
			sd.second = stoi(trim(tempSplitSplit[1]));
			minCoordinationNumber.push_back(sd);
		}
	}
	else if (option == "maxCoordinationNumber") {
		vector<string> tempSplit = split(value, ',');
		vector<string> tempSplitSplit;
		for (int i = 0; i<tempSplit.size(); ++i) {
			pair<string, int> sd;
			tempSplit[i] = trim(tempSplit[i]);
			tempSplitSplit = split(tempSplit[i], ':');
			sd.first = trim(tempSplitSplit[0]);
			sd.second = stoi(trim(tempSplitSplit[1]));
			maxCoordinationNumber.push_back(sd);
		}
	}
	else if (option == "periodicalRange") {
		periodicalRange = stoi(value);
	}
	else if (option == "maxNumOfSharedVertexes")
	{
		vector<string> tempSplit = split(value, ',');
		for (int i = 0; i<tempSplit.size(); ++i)
		{
			pair<pair<string, string>, int> ssi;
			vector<string> tempString;
			tempSplit[i] = trim(tempSplit[i]);
			tempString = split(tempSplit[i], ':');
			ssi.first.first = trim(split(tempString[0], '-')[0]);
			ssi.first.second = trim(split(tempString[0], '-')[1]);
			ssi.second = stoi(trim(tempString[1]));
			maxNumOfSharedVertexes.push_back(ssi);
		}
	}
	else if (option == "maxNumOfAtomsOnPolyhedron")
	{
		vector<string> tempSplit1 = split(value, ';');
		for (size_t i = 0; i < tempSplit1.size(); i++)
		{
			vector<pair<string, int>> tempArray;
			vector<string> tempSplit2 = split(tempSplit1[i], ':');
			string centalAtom = trim(tempSplit2[0]);
			vector<string> tempSplit3 = split(tempSplit2[1], ',');
			for (size_t j = 0; j < tempSplit3.size(); j++)
			{
				vector<string> tempSplit4 = split(tempSplit3[j], '/');
				string atom = trim(tempSplit4[0]);
				int num = stoi(trim(tempSplit4[1]));
				tempArray.push_back(pair<string, int>(atom, num));
			}//j
			maxNumOfAtomsOnPolyhedron.push_back(pair<string, vector<pair<string, int>>>(centalAtom, tempArray));
		}//i
	}
	else if (option == "maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg") {
		maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg = stoi(value);
	}
	else if (option == "maxNumOfOutputFilesForEachSimilarStructureType") {
		maxNumOfOutputFilesForEachSimilarStructureType = stoi(value);
	}
	else if (option == "lenTol") {
		lenTol = stod(value);
	}
	else if (option == "posTol") {
		posTol = stod(value);
	}
	else if (option == "angleTol") {
		angleTol = stod(value);
	}
	else if (option == "xtalComp") {
		if (value[0] == 'F' || value[0] == 'f')
			xtalComp = false;
		else if (value[0] == 'T' || value[0] == 't')
			xtalComp = true;
		else {
			cerr << "Error reading 'xtalComp' setting: " << value
				<< "\nValid settings are 'True' or 'False' or 'T' or 'F'\n";
			cerr << "The value will remain the default: False\n";
		}
	}
    else {
		cout << "The input parameters: '" << option << "' are wrong! Please check the Crystalpicker.in file." << endl;
		exit(0);
    }
}

