/**********************************************************************
countBonds.cpp - Count chemical bond related data in crystals.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/

#include <iostream>
#include "countBonds.h"

#ifdef _WIN32
#include "..\polyhedron\polyhedron.h"
#else
#include "../polyhedron/polyhedron.h"
#endif

using namespace std;

double bondingPairDistance(const vector<pair<string, int>>& components, vector<pair<pair<string, string>, double>> bondingPair, const int& element1, const int& element2) {
	for (int i = 0; i < bondingPair.size(); ++i) {
		if ((bondingPair[i].first.first == components[element1].first) && (bondingPair[i].first.second == components[element2].first)) {
			return bondingPair[i].second;
		}
		else if ((bondingPair[i].first.first == components[element2].first) && (bondingPair[i].first.second == components[element1].first)) {
			return bondingPair[i].second;
		}
		else
			continue;
	}
	//If they are not a bonded atom pair, return a negative value.
	return -10.0;
}

bool checkMinDistanceOfAtoms(const readOptions& options, const int& periodicalRange, const crystalInfo& crystal, const int& element1, const int& num1, const int& element2, const int& num2)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = options.get_minDistanceOfAtoms();
	double defaultMinDistanceOfAtoms = options.get_defaultMinDistanceOfAtoms();
	//
	double minDistance = calMinDistance(periodicalRange, crystal, element1, num1, element2, num2);
	//
	for (int i = 0; i < minDistanceOfAtoms.size(); ++i) {
		if (minDistanceOfAtoms[i].first.first == components[element1].first && minDistanceOfAtoms[i].first.second == components[element2].first) {
			if (minDistance < minDistanceOfAtoms[i].second) {
				return false;
			}
			else
			{
				return true;
			}
		}//case1
		if (minDistanceOfAtoms[i].first.first == components[element2].first && minDistanceOfAtoms[i].first.second == components[element1].first) {
			if (minDistance < minDistanceOfAtoms[i].second) {
				return false;
			}
			else
			{
				return true;
			}
		}//case2
	}//i
	 //If there is no match
	if (minDistance < defaultMinDistanceOfAtoms) {
		return false;
	}
	else
	{
		return true;
	}
}

double calMinDistance(const int& periodicalRange, const crystalInfo& crystal, const int& element1, const int& num1, const int& element2, const int& num2)
{
	lattVec latticeVectors = crystal.get_latticeVectors();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	//
	vector<NVECTOR> periodicAtoms;
	cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element2][num2], periodicAtoms, periodicalRange);
	//
	double min;
	if (element1 == element2 && num1 == num2)
	{
		min = Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[1]);
	}
	else
	{
		min = Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[0]);
	}
	//
	for (int i = 1; i < periodicAtoms.size(); ++i) {
		if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[i]) < min)
		{
			min = Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[i]);
		}
	}
	//
	return min;
}

bool checkMinIADForCrystal(const crystalInfo& crystal, const readOptions& iterationOptions)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	//
	for (int element1 = 0; element1 < components.size(); ++element1) {
		//
		for (int element2 = element1; element2 < components.size(); ++element2) {
			//
			for (int num1 = 0; num1 < components[element1].second; ++num1) {
				//
				for (int num2 = 0; num2 < components[element2].second; ++num2) {
					//
					if (!checkMinDistanceOfAtoms(iterationOptions, periodicalRange, crystal, element1, num1, element2, num2))
					{
						return false;
					}//checkMinDistanceOfAtoms
				}//num2
			}//num1
		}//element2
	}//element1
	return true;
}

void countChemicalBonds(vector<int>& numberOfChemicalBonds, const vector<crystalInfo>& crystals, const readOptions& options) {
	
	vector<pair<pair<string, string>, double>> bondingPair = options.get_bondingPairs();
	int periodicalRange = options.get_periodicalRange();

	for (int i = 0; i < crystals.size(); ++i) {
		vector<pair<string, int>> components = crystals[i].get_components();
		atom cartesianCoordinates = crystals[i].get_cartesianCoordinates();
		lattVec latticeVectors = crystals[i].get_latticeVectors();
		//
		int totalNumberOfBonds = 0;
		//
		for (int element1 = 0; element1 < components.size(); ++element1) {
			//
			for (int element2 = element1; element2 < components.size(); ++element2) {
				//
				for (int num1 = 0; num1 < components[element1].second; ++num1) {
					//
					for (int num2 = (element1 == element2 ? num1 : 0); num2 < components[element2].second; ++num2) {
						//Find periodic atomic coordinates in the range of "periodicRange".
						//The atom in the unit cell is stored in periodicAtoms[0].
						vector<NVECTOR> periodicAtoms;
						cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element2][num2], periodicAtoms, periodicalRange);

						for (int n = 0; n < periodicAtoms.size(); ++n)
						{
							if (n == 0)
							{
								//Skip the coordinates of the same atom.
								if (element1 == element2 && num1 == num2)
								{
									continue;
								}
							}
							//
							if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[n])
								< bondingPairDistance(components, bondingPair, element1, element2)) {
								totalNumberOfBonds += 1;
							}
						}//n
					}//num2
				}//num1
			}//element2
		}//element1
		numberOfChemicalBonds.push_back(totalNumberOfBonds);
	}//i
}

int countChemicalBonds(const crystalInfo& crystal, const readOptions& options, const vector<pair<pair<string, string>, double>>& atomPairs)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = options.get_minDistanceOfAtoms();
	int periodicalRange = options.get_periodicalRange();
	//
	int totalNumberOfBonds = 0;
	//
	for (int element1 = 0; element1 < components.size(); ++element1) {
		//
		for (int element2 = element1; element2 < components.size(); ++element2) {
			//
			for (int num1 = 0; num1 < components[element1].second; ++num1) {
				//
				for (int num2 = (element1 == element2 ? num1 : 0); num2 < components[element2].second; ++num2) {
					//Find periodic atomic coordinates in the range of "periodicRange".
					//The atom in the unit cell is stored in periodicAtoms[0].
					vector<NVECTOR> periodicAtoms;
					cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element2][num2], periodicAtoms, periodicalRange);

					for (int n = 0; n < periodicAtoms.size(); ++n)
					{
						if (n == 0)
						{
							//Skip the coordinates of the same atom.
							if (element1 == element2 && num1 == num2)
							{
								continue;
							}
						}
						//
						if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[n])
							< bondingPairDistance(components, atomPairs, element1, element2)) {
							totalNumberOfBonds += 1;
						}
					}//n					
				}//num2
			}//num1
		}//element2
	}//element1
	return totalNumberOfBonds;
}

void cartesianCoordinatesOfPeriodicAtoms(const lattVec& latticeVectors, const NVECTOR& atomSite, vector<NVECTOR>& periodicAtoms, const int& periodicalRange)
{
	//periodicAtoms[0] stores the coordinate of the original site
	periodicAtoms.push_back(atomSite);
	//
	for (int i = -periodicalRange; i <= periodicalRange; ++i)
	{
		for (int j = -periodicalRange; j <= periodicalRange; ++j)
		{
			for (int k = -periodicalRange; k <= periodicalRange; ++k)
			{
				if (i == 0 && j == 0 && k == 0)
				{
					continue;
				}
				//atomSite + i*a + j*b + k*c
				periodicAtoms.push_back(atomSite + i*latticeVectors.a[0] + j*latticeVectors.a[1] + k*latticeVectors.a[2]);
			}//k
		}//j
	}//i
}

int getElementNum(const vector<pair<string, int>>& components, const string& elementName)
{
	for (int element = 0; element < components.size(); ++element)
	{
		if (components[element].first == elementName)
		{
			return element;
		}
	}
}

bool checkNumOfSharedVertexes(const crystalInfo& crystal, const readOptions& iterationOptions)
{
	vector<pair<pair<string, string>, int>> maxNumOfSharedVertexes = iterationOptions.get_maxNumOfSharedVertexes();
	vector<pair<pair<string, string>, double>> atomPairs = iterationOptions.get_bondingPairs();
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	const double overlap = 1.0e-3;
	//
	for (size_t i = 0; i < maxNumOfSharedVertexes.size(); i++)
	{
		int element1 = getElementNum(components, maxNumOfSharedVertexes[i].first.first);
		int element3 = getElementNum(components, maxNumOfSharedVertexes[i].first.second);
		for (size_t num1 = 0; num1 < components[element1].second; num1++)
		{
			for (size_t num3 = (element1 == element3 ? num1 : 0); num3 < components[element3].second; num3++)
			{
				vector<NVECTOR> periodicAtoms3;
				cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element3][num3], periodicAtoms3, periodicalRange);
				for (int m = 0; m < periodicAtoms3.size(); ++m)
				{
					int numOfSharedVertexes = 0;
					if (m == 0)
					{
						//Skip the coordinates of the same atom.
						if (element1 == element3 && num1 == num3)
						{
							continue;
						}
					}
					//
					for (size_t element2 = 0; element2 < components.size(); element2++)
					{
						for (size_t num2 = 0; num2 < components[element2].second; num2++)
						{
							vector<NVECTOR> periodicAtoms2;
							cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element2][num2], periodicAtoms2, periodicalRange);
							for (int n = 0; n < periodicAtoms2.size(); ++n)
							{
								if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms2[n]) < overlap ||
									Ndistance(periodicAtoms3[m], periodicAtoms2[n]) < overlap)
								{
									//This "shared vertex" is actually periodicAtoms3[m] or (element1, num1), and is not really a shared vertex.
									continue;
								}
								if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms2[n]) < bondingPairDistance(components, atomPairs, element1, element2) &&
									Ndistance(periodicAtoms3[m], periodicAtoms2[n]) < bondingPairDistance(components, atomPairs, element3, element2))
								{
									numOfSharedVertexes += 1;
								}
							}//n
						}//num2
					}//k
					if (numOfSharedVertexes > maxNumOfSharedVertexes[i].second)
					{
						return false;
					}
				}//m				
			}//num3
		}//num1
	}//i
	return true;
}

bool isPyramidalPolyhedron(const NVECTOR& polyhedronCenter, const vector<NVECTOR>& coordinationAtoms)
{
	//If this is a pyramidal coordinated polyhedron, 
	//there must be a plane through the central atom, 
	//so that all coordination atoms are on the plane or on one side of this plane.

	const double EPS = 1.0e-6;

	//Center atom as origin
	vector<NVECTOR> tempCoordinationAtoms = coordinationAtoms;
	for (size_t i = 0; i < coordinationAtoms.size(); i++)
	{
		tempCoordinationAtoms[i] = coordinationAtoms[i] - polyhedronCenter;
	}

	
	for (size_t j = 0; j < tempCoordinationAtoms.size(); j++)
	{
		for (size_t k = j + 1; k < tempCoordinationAtoms.size(); k++)
		{
			//Find two other coordination atoms that are not collinear with the central atom
			if (vec_norm(crossdot(tempCoordinationAtoms[j], tempCoordinationAtoms[k])) > EPS)
			{
				NVECTOR normalVector = crossdot(tempCoordinationAtoms[j], tempCoordinationAtoms[k]);
				//Determine if other coordination atoms are on the same side of the plane
				int numOfAtomsAboveThePlane = 0;
				int numOfAtomsBelowThePlane = 0;
				int numOfAtomsOnThePlane = 0;
				for (size_t n = 0; n < tempCoordinationAtoms.size(); n++)
				{
					if (abs(dot(normalVector, tempCoordinationAtoms[n])) < EPS)
					{
						numOfAtomsOnThePlane = numOfAtomsOnThePlane + 1;
						continue;
					}
					if (dot(normalVector, tempCoordinationAtoms[n]) > EPS)
					{
						numOfAtomsAboveThePlane = numOfAtomsAboveThePlane + 1;
						continue;
					}
					if (dot(normalVector, tempCoordinationAtoms[n]) < -EPS)
					{
						numOfAtomsBelowThePlane = numOfAtomsBelowThePlane + 1;
						continue;
					}
				}//n	
				if ((numOfAtomsAboveThePlane == tempCoordinationAtoms.size() - numOfAtomsOnThePlane) || (numOfAtomsBelowThePlane == tempCoordinationAtoms.size() - numOfAtomsOnThePlane))
				{
					return true;//this is a pyramidal coordinated polyhedron
				}
			}//if				
		}//k
	}//j
	return false;
}

double getVolumeOfPolyhedron(const vector<NVECTOR>& coordinationAtoms)
{
	if (coordinationAtoms.size() < 4)
	{
		return 0.0;
	}
	//
	int num_vertex = coordinationAtoms.size();
	double **vertex;
	vertex = new double*[num_vertex];
	for (int t1 = 0; t1<num_vertex; t1++)
		vertex[t1] = new double[3];

	for (int t1 = 0; t1 < num_vertex; t1++)
	{
		vertex[t1][0] = coordinationAtoms[t1].x;
		vertex[t1][1] = coordinationAtoms[t1].y;
		vertex[t1][2] = coordinationAtoms[t1].z;
	}
	polyhedron p1;
	p1.init(num_vertex);
	p1.import_vertex(vertex);
	double volume = p1.get_volume();
	//Free dynamic memory
	for (int t1 = 0; t1 < num_vertex; t1++)
	{
		delete[] vertex[t1];
	}
	delete[] vertex;
	return volume;
}

bool checkForbiddenPyramidalPolyhedrons(const crystalInfo& crystal, const readOptions& iterationOptions)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	vector<pair<pair<string, string>, double>> atomPairs = iterationOptions.get_bondingPairs();
	vector<string> forbiddenPyramidalPolyhedrons = iterationOptions.get_forbiddenPyramidalPolyhedrons();
	//
	for (size_t i = 0; i < forbiddenPyramidalPolyhedrons.size(); i++)
	{
		int element = getElementNum(components, forbiddenPyramidalPolyhedrons[i]);
		for (size_t num = 0; num < components[element].second; num++)
		{
			int coordinationNum = 0;
			vector<NVECTOR> coordinationAtoms;
			//search coordination Atoms
			for (size_t element1 = 0; element1 < components.size(); element1++)
			{
				for (size_t num1 = 0; num1 < components[element1].second; num1++)
				{
					vector<NVECTOR> periodicAtoms;
					cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element1][num1], periodicAtoms, periodicalRange);

					for (int n = 0; n < periodicAtoms.size(); ++n)
					{
						//Skip the coordinates of the same atom
						if (n == 0)
						{
							if (element1 == element && num1 == num)
							{
								continue;
							}
						}
						//
						if (Ndistance(cartesianCoordinates[element][num], periodicAtoms[n])
							< bondingPairDistance(components, atomPairs, element, element1))
						{
							coordinationNum += 1;
							coordinationAtoms.push_back(periodicAtoms[n]);
						}
					}//n
				}//num1
			}//element1
			//consider only the polyhedrons whose coordination number is not less than 4.
			//If the coordination number is less than 4, return true directly.
			if (coordinationNum >= 4)
			{
				if (isPyramidalPolyhedron(cartesianCoordinates[element][num], coordinationAtoms))
				{
					return false;
				}
			}
		}//num
	}//i
	return true;
}

bool checkMinVolumeOfPolyhedrons(const crystalInfo& crystal, const readOptions& iterationOptions)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	vector<pair<pair<string, string>, double>> atomPairs = iterationOptions.get_bondingPairs();
	vector<pair<string, double>> minVolumeOfPolyhedrons = iterationOptions.get_minVolumeOfPolyhedrons();
	//
	for (size_t i = 0; i < minVolumeOfPolyhedrons.size(); i++)
	{
		int element = getElementNum(components, minVolumeOfPolyhedrons[i].first);
		for (size_t num = 0; num < components[element].second; num++)
		{
			int coordinationNum = 0;
			vector<NVECTOR> coordinationAtoms;
			//search coordination Atoms
			for (size_t element1 = 0; element1 < components.size(); element1++)
			{
				for (size_t num1 = 0; num1 < components[element1].second; num1++)
				{
					vector<NVECTOR> periodicAtoms;
					cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element1][num1], periodicAtoms, periodicalRange);

					for (int n = 0; n < periodicAtoms.size(); ++n)
					{
						//Skip the coordinates of the same atom
						if (n == 0)
						{
							if (element1 == element && num1 == num)
							{
								continue;
							}
						}
						//
						if (Ndistance(cartesianCoordinates[element][num], periodicAtoms[n])
							< bondingPairDistance(components, atomPairs, element, element1))
						{
							coordinationNum += 1;
							coordinationAtoms.push_back(periodicAtoms[n]);
						}
					}//n
				}//num1
			}//element1
			 //consider only the polyhedrons whose coordination number is not less than 4.
			if (coordinationNum >= 4)
			{
				if (isPyramidalPolyhedron(cartesianCoordinates[element][num], coordinationAtoms))
				{
					return false;//If it is a pyramid polyhedron, return false directly
				}
				else
				{
					double volume = getVolumeOfPolyhedron(coordinationAtoms);
					if (volume < minVolumeOfPolyhedrons[i].second)
					{
						return false;
					}
				}
			}//if 
		}//num
	}//i
	return true;
}

bool checkCoordinationNumber(const crystalInfo& crystal, const readOptions& options)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = options.get_minDistanceOfAtoms();
	int periodicalRange = options.get_periodicalRange();
	vector<pair<pair<string, string>, double>> atomPairs = options.get_bondingPairs();
	vector<pair<string, int>> minCoordinationNumbers = options.get_minCoordinationNumber();
	vector<pair<string, int>> maxCoordinationNumbers = options.get_maxCoordinationNumber();
	//
	for (size_t i = 0; i < minCoordinationNumbers.size(); i++)
	{
		int element1 = getElementNum(components, minCoordinationNumbers[i].first);
		for (int num1 = 0; num1 < components[element1].second; ++num1) {
			//
			int totalNumberOfBonds = 0;
			for (int element2 = 0; element2 < components.size(); ++element2) {
				//
				for (int num2 = 0; num2 < components[element2].second; ++num2) {
					
					vector<NVECTOR> periodicAtoms;
					cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element2][num2], periodicAtoms, periodicalRange);

					for (int n = 0; n < periodicAtoms.size(); ++n)
					{
						//Skip the coordinates of the same atom.
						if (n == 0)
						{
							if (element1 == element2 && num1 == num2)
							{
								continue;
							}
						}
						//
						if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[n])
							< bondingPairDistance(components, atomPairs, element1, element2)) {
							totalNumberOfBonds += 1;
						}
					}//n
				}//num2
			}//element2
			if (totalNumberOfBonds < minCoordinationNumbers[i].second)
			{
				return false;
			}
		}//num1
	}//i

	for (size_t i = 0; i < maxCoordinationNumbers.size(); i++)
	{
		int element1 = getElementNum(components, maxCoordinationNumbers[i].first);
		for (int num1 = 0; num1 < components[element1].second; ++num1) {
			//
			int totalNumberOfBonds = 0;
			for (int element2 = 0; element2 < components.size(); ++element2) {
				//
				for (int num2 = 0; num2 < components[element2].second; ++num2) {
					
					vector<NVECTOR> periodicAtoms;
					cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element2][num2], periodicAtoms, periodicalRange);

					for (int n = 0; n < periodicAtoms.size(); ++n)
					{
						//Skip the coordinates of the same atom.
						if (n == 0)
						{
							if (element1 == element2 && num1 == num2)
							{
								continue;
							}
						}
						//
						if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[n])
							< bondingPairDistance(components, atomPairs, element1, element2)) {
							totalNumberOfBonds += 1;
						}
					}//n					
				}//num2
			}//element2
			if (totalNumberOfBonds > maxCoordinationNumbers[i].second)
			{
				return false;
			}
		}//num1
	}//i

	return true;
}

bool checkMaxNumOfAtomsOnPolyhedron(const crystalInfo& crystal, const readOptions& iterationOptions)
{
	//��������Լ�bondingPair��Ϣ
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	auto atomPairs = iterationOptions.get_bondingPairs();
	auto maxNumOfAtomsOnPolyhedron = iterationOptions.get_maxNumOfAtomsOnPolyhedron();
	//
	for (size_t i = 0; i < maxNumOfAtomsOnPolyhedron.size(); i++)
	{
		int centralAtom = getElementNum(components, maxNumOfAtomsOnPolyhedron[i].first);
		if (centralAtom == -1)
		{
			continue;
		}
		for (size_t num = 0; num < components[centralAtom].second; num++)
		{
			for (size_t j = 0; j < maxNumOfAtomsOnPolyhedron[i].second.size(); j++)
			{
				int coordinationAtom = getElementNum(components, maxNumOfAtomsOnPolyhedron[i].second[j].first);
				if (coordinationAtom == -1)
				{
					continue;
				}
				//Calculate the coordination number between coordinationAtom_num1 and centralAtom
				int coordinationNum = 0;
				for (size_t num1 = 0; num1 < components[coordinationAtom].second; num1++)//coordinationAtom_num1
				{
					vector<NVECTOR> periodicAtoms;
					cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[coordinationAtom][num1], periodicAtoms, periodicalRange);

					for (int n = 0; n < periodicAtoms.size(); ++n)
					{
						//Skip the coordinates of the same atom.
						if (n == 0)
						{
							if (centralAtom == coordinationAtom && num1 == num)
							{
								continue;
							}
						}
						//
						if (Ndistance(cartesianCoordinates[centralAtom][num], periodicAtoms[n])
							< bondingPairDistance(components, atomPairs, coordinationAtom, centralAtom))
						{
							coordinationNum += 1;
						}
					}//n
				}//num1
				if (coordinationNum > maxNumOfAtomsOnPolyhedron[i].second[j].second)
				{
					return false;
				}
			}//j
		}//num
	}//i
	return true;
}