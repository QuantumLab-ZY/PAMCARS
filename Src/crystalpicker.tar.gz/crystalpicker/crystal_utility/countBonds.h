/**********************************************************************
countBonds.h - Count chemical bond related data in crystals.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/

#include <vector>
#include <string>
#include "readOptions.h"
#include "structure.h"
#include "vectorOperations.h"
#include "utilityFunctions.h"

#ifndef COUNTBONDS_H
#define COUNTBONDS_H

void cartesianCoordinatesOfPeriodicAtoms(const lattVec& latticeVectors, const NVECTOR& atomSite, std::vector<NVECTOR>& periodicAtoms, const int& periodicalRange);

double bondingPairDistance(const std::vector<std::pair<std::string, int>>& components, std::vector<std::pair<std::pair<std::string, std::string>, double>> bondingPair, const int& element1, const int& element2);

bool checkMinDistanceOfAtoms(const readOptions& options, const int& periodicalRange, const crystalInfo& crystal, const int& element1, const int& num1, const int& element2, const int& num2);

double calMinDistance(const int& periodicalRange, const crystalInfo& crystal, const int& element1, const int& num1, const int& element2, const int& num2);

bool checkMinIADForCrystal(const crystalInfo& crystal, const readOptions& iterationOptions);

void countChemicalBonds(std::vector<int>& numberOfChemicalBonds, const std::vector<crystalInfo>& crystals, const readOptions& options);

int countChemicalBonds(const crystalInfo& crystal, const readOptions& options, const std::vector<std::pair<std::pair<std::string, std::string>, double>>& atomPairs);

bool checkNumOfSharedVertexes(const crystalInfo& crystal, const readOptions& iterationOptions);

bool isPyramidalPolyhedron(const NVECTOR& polyhedronCenter, const std::vector<NVECTOR>& coordinationAtoms);

double getVolumeOfPolyhedron(const std::vector<NVECTOR>& coordinationAtoms);

bool checkForbiddenPyramidalPolyhedrons(const crystalInfo& crystal, const readOptions& iterationOptions);

bool checkMinVolumeOfPolyhedrons(const crystalInfo& crystal, const readOptions& iterationOptions);

bool checkCoordinationNumber(const crystalInfo& crystal, const readOptions& options);

bool checkMaxNumOfAtomsOnPolyhedron(const crystalInfo& crystal, const readOptions& iterationOptions);

#endif