/*****************************************************************************
main.cpp - Main function for crystalpicker.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
******************************************************************************/

#include <vector>
#include <string>
#include <map>

#ifdef _WIN32
#include ".\crystal_utility\readOptions.h"
#include ".\crystal_utility\structure.h"
#include ".\crystal_utility\vectorOperations.h"
#include ".\crystal_utility\utilityFunctions.h"
#include ".\polyhedron\polyhedron.h"
#include".\xtalcomp\xtalcomp.h"
#include ".\xtalInfo\xtalInfo.h"
#include ".\math\indexx.h"
#include ".\crystal_utility\countBonds.h"
#else
#include "./crystal_utility/readOptions.h"
#include "./crystal_utility/structure.h"
#include "./crystal_utility/vectorOperations.h"
#include "./crystal_utility/utilityFunctions.h"
#include "./polyhedron/polyhedron.h"
#include"./xtalcomp/xtalcomp.h"
#include "./xtalInfo/xtalInfo.h"
#include "./math/indexx.h"
#include "./crystal_utility/countBonds.h"
#endif

using namespace std;

int main(int argc, char **argv) 
{

	//Read input parameters from crystalpicker.in
	readOptions options = readOptions::readInput("Crystalpicker.in");

	//Check if the settings of localBondingPair and minNumOfLocalBonds are compatible.
	if (options.get_localBondingPairs().size() != options.get_minNumOfLocalBonds().size())
	{
		cout << "The parameter 'localBondingPair' is not compatible with the parameter 'minNumOfLocalBonds'!" << endl;
	}

	//Read each random structure's POSCAR file in the inDir directory
	string inDir = options.get_inputDir();
#ifdef _WIN32
	inDir += "\\";
#else
	inDir += "/";
#endif
	vector<uint> spacegroups = options.getSpacegroups();
	int totalNumOfOutputFiles = 0;
	for (size_t n = 0; n < spacegroups.size(); n++)
	{
		uint spg = spacegroups[n];
		//all POSCAR files is saved in crystals
		vector<crystalInfo>	crystals;
		//structureTypes[i][j]:the j-th structure in i-th similar structure type
		vector<vector<crystalInfo>> structureTypes;
		//File ID number corresponding to each POSCAR file
		vector<int> crystalsId;
		//Map of POSCAR file ID number with index number in crystals
		map<int, int> id2num;
		//max number of POSCAR files of each space group
		int maxNumOfFilesForEachSpg = options.get_maxNumOfFilesForEachSpg();
		//Actual number of crystal structures
		int totalNumOfstructures;

		//Read POSCAR files
		if (true)
		{
			int num = -1;
			for (int i = 0; i < maxNumOfFilesForEachSpg; ++i)
			{
				int fileId = 1 + i;
				string filename = inDir + options.get_poscarFilename() + "_" + to_string(spg) + "-" + to_string(fileId) + ".vasp";
				crystalInfo tempCrystal;
				if (tempCrystal.readPoscar(filename))
				{
					//Check the distances between atoms
					if (!checkMinIADForCrystal(tempCrystal, options))
					{
						goto nextPoscarFile;
					}
					//Check if the num of local bonds in POSCAR reach the min number of local bonds
					vector<vector<pair<pair<string, string>, double>>> localBondingPair = options.get_localBondingPairs();
					vector<int> minNumOfLocalBonds = options.get_minNumOfLocalBonds();
					if (localBondingPair.size() == minNumOfLocalBonds.size())
					{
						for (size_t j = 0; j < localBondingPair.size(); j++)
						{
							int numOfLocalBonds = countChemicalBonds(tempCrystal, options, localBondingPair[j]);
							if (numOfLocalBonds < minNumOfLocalBonds[j])
							{
								goto nextPoscarFile;
							}
						}//j
					}
					//Check the number of shared vertices of coordinated polyhedrons
					if (!checkNumOfSharedVertexes(tempCrystal, options))
					{
						goto nextPoscarFile;
					}
					//Check if There is a pyramidal coordinated polyhedron in the crystal
					if (!checkForbiddenPyramidalPolyhedrons(tempCrystal, options))
					{
						goto nextPoscarFile;
					}
					//Check if the volume of the coordinated polyhedrons in the crystal exceed 
					//the minimum allowable volume.
					if (!checkMinVolumeOfPolyhedrons(tempCrystal, options))
					{
						goto nextPoscarFile;
					}
					//Check the coordination number of each cation in the crystal
					if (!checkCoordinationNumber(tempCrystal, options))
					{
						goto nextPoscarFile;
					}
					//Check if some coordinated polyhedrons in the crystal 
					//possess an excessive number of certain anions.
					if (!checkMaxNumOfAtomsOnPolyhedron(tempCrystal, options))
					{
						goto nextPoscarFile;
					}
					if (options.get_xtalComp())
					{
						//Check structure similarity. Only maxNumOfOutputFilesForEachSimilarStructureType crystals 
						//are allowed in each type of similar structure.
						int maxNumOfOutputFilesForEachSimilarStructureType = options.get_maxNumOfOutputFilesForEachSimilarStructureType();
						double lenTol = options.get_lenTol(), angleTol = options.get_angleTol(), posTol = options.get_posTol();
						for (size_t i_ = 0; i_ < structureTypes.size(); i_++)
						{
							for (size_t j_ = 0; j_ < structureTypes[i_].size(); j_++)
							{
								xtalInfo xtal, tempXtal;
								xtal.setFromCrystalInfo(structureTypes[i_][j_]);
								tempXtal.setFromCrystalInfo(tempCrystal);
								if (xtalInfo::similarityCompare(xtal, tempXtal, lenTol, angleTol, posTol))//�������
								{
									if (structureTypes[i_].size() < maxNumOfOutputFilesForEachSimilarStructureType)//��������������洢�����ƽṹ��
									{
										structureTypes[i_].push_back(tempCrystal);
										num++;
										crystals.push_back(tempCrystal);
										crystalsId.push_back(fileId);
										id2num[fileId] = num;
										goto nextPoscarFile;
									}
									else
									{
										//Similar�� but exceed the maximum allowed number
										//Read next POSCAR file
										goto nextPoscarFile;
									}
								}
							}//j_
						}//i_
						/*
						There are two cases where the program can reach here:
						1��structureTypes is empty
						2��structureTypes is not empty��but none of the saved crystal structures are similar to tempCrystal.
						   tempCrystal is a new structure type.
						*/
						structureTypes.resize(structureTypes.size() + 1);
						structureTypes.back().push_back(tempCrystal);
						num++;
						crystals.push_back(tempCrystal);
						crystalsId.push_back(fileId);
						id2num[fileId] = num;
					}//xtalComp
					else
					{
						num++;
						crystals.push_back(tempCrystal);
						crystalsId.push_back(fileId);
						id2num[fileId] = num;
					}
				}//if
			nextPoscarFile:;
			}//i
		}//if
		totalNumOfstructures = crystals.size();

		//Save the number of bonds of all crystal structures
		vector<int>	numOfChemicalBondsOfAllCrystals;
		//Save the number of chemical bonds no less than minNumberOfBonds
		vector<int> numOfChemicalBondsOfAvailableCrystals; 

		//Calculate the number of chemical bonds for each POSCAR file
		countChemicalBonds(numOfChemicalBondsOfAllCrystals, crystals, options);
		
		//store the file ID of the crystal structures whose number of chemical bonds 
		//is no less than minNumberOfBonds
		vector<int> crystalsIdOfAvailableCrystals;
		int numOfAvailableCrystals;
		//File IDs of the POSCAR files to be output
		vector<int> crystalsIdOfOutputCrystals;
		//Total number of crystals that can be output
		int numOfFilesToExport = 0;
		vector<int> numOfChemicalBondsOfOutputCrystals;
		
		for (int i = 0; i < totalNumOfstructures; ++i)
		{
			int minNumberOfBonds = options.get_minNumberOfBonds();
			if (numOfChemicalBondsOfAllCrystals[i] >= minNumberOfBonds)
			{
				numOfChemicalBondsOfAvailableCrystals.push_back(numOfChemicalBondsOfAllCrystals[i]);
				crystalsIdOfAvailableCrystals.push_back(crystalsId[i]);
			}
		}
		numOfAvailableCrystals = numOfChemicalBondsOfAvailableCrystals.size();
		//
		if (numOfAvailableCrystals == 0)
		{
			continue;//goto next spg
		}
		vector<double> ss(numOfAvailableCrystals);
		vector<unsigned long> index(numOfAvailableCrystals);
		for (int i = 0; i < numOfAvailableCrystals; ++i) {
			ss[i] = -numOfChemicalBondsOfAvailableCrystals[i];
		}
		//Sort the number of chemical bonds in descending order
		indexx(numOfAvailableCrystals, &ss[0], &index[0]);
		//
		crystalsIdOfOutputCrystals.resize(numOfAvailableCrystals);
		numOfChemicalBondsOfOutputCrystals.resize(numOfAvailableCrystals);

		//
		int maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg = options.get_maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg();
		map<int, miniVector<int>> crystalsToExport;
		for (int i = 0; i < numOfAvailableCrystals; ++i)
		{
			crystalsToExport[numOfChemicalBondsOfAvailableCrystals[index[i]]].resetMaxSize(maxNumOfOutputFilesWithTheSameNumOfBondsForEachSpg);
			if (crystalsToExport[numOfChemicalBondsOfAvailableCrystals[index[i]]].push_back(crystalsIdOfAvailableCrystals[index[i]]))
			{
				crystalsIdOfOutputCrystals[numOfFilesToExport] = crystalsIdOfAvailableCrystals[index[i]];
				numOfChemicalBondsOfOutputCrystals[numOfFilesToExport] = numOfChemicalBondsOfAvailableCrystals[index[i]];
				numOfFilesToExport++;
			}

		}
		//Output the first maxNumOfFilesForEachSpg structures 
		//with the largest number of chemical bonds.
		string outDir1 = options.get_outputDir() + "_rank";
		string outDir2 = options.get_outputDir() + "_toBeRelaxed";
		mkDir(outDir1);
		mkDir(outDir2);
#ifdef _WIN32
		outDir1 += "\\";
		outDir2 += "\\";
#else
		outDir1 += "/";
		outDir2 += "/";
#endif
		for (int i = 0; i < options.get_maxNumOfOutputFilesForEachSpg(); ++i)
		{
			if (i >= numOfFilesToExport)
			{
				break;
			}
			//
			int crystalId = crystalsIdOfOutputCrystals[i];
			if ((crystalId >= 1) && (crystalId <= maxNumOfFilesForEachSpg))
			{
				string outPoscar1 = outDir1 + options.get_poscarFilename() + "_" + to_string(spg) + "rank" + to_string(i + 1) + "_" + to_string(numOfChemicalBondsOfOutputCrystals[i]) + ".vasp";
				string outPoscar2 = outDir2 + options.get_poscarFilename() + "_" + to_string(totalNumOfOutputFiles + i + 1) + ".vasp";
				crystals[id2num[crystalId]].writePoscar(outPoscar1);
				crystals[id2num[crystalId]].writePoscar(outPoscar2);
			}
		}//i
	    if (options.get_maxNumOfOutputFilesForEachSpg() >= numOfFilesToExport)
		{
			totalNumOfOutputFiles += numOfFilesToExport;
		}
		else
		{
			totalNumOfOutputFiles += options.get_maxNumOfOutputFilesForEachSpg();
		}	
	}//n
	return 0;
}
