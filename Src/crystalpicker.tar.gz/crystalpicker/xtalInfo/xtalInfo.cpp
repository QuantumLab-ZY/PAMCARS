#include "xtalInfo.h"
#ifdef _WIN32
#include "..\xtalcomp\xtalcomp.h"
#else
#include "../xtalcomp/xtalcomp.h"
#endif


xtalInfo::xtalInfo(const crystalInfo& crystal)
{
	//Set cell
	auto latt = crystal.get_latticeVectors();
	cell = XcMatrix(latt.a[0].x, latt.a[0].y, latt.a[0].z, latt.a[1].x, latt.a[1].y, latt.a[1].z, latt.a[2].x, latt.a[2].y, latt.a[2].z);
	//set pos
	pos = std::vector<XcVector>();
	auto atom = crystal.get_fractionalCoordinates();
	for (size_t i = 0; i < atom.size(); i++)
	{
		for (size_t j = 0; j < atom[i].size(); j++)
		{
			pos.push_back(XcVector(atom[i][j].x, atom[i][j].y, atom[i][j].z));
		}
	}
	//set types
	types = std::vector<unsigned int>();
	auto components = crystal.get_components();
	for (size_t i = 1; i <= components.size(); i++)
	{
		for (size_t j = 0; j < components[i-1].second; j++)
		{
			types.push_back(i);
		}
	}
	//Lattice parameters
	a = crystal.get_a();
	b = crystal.get_b();
	c = crystal.get_c();
	alpha = crystal.get_alpha();
	beta = crystal.get_beta();
	gamma = crystal.get_gamma();
	volume = crystal.get_volume();
}

void xtalInfo::setFromCrystalInfo(const crystalInfo& crystal) 
{
	*this = xtalInfo(crystal);
}
bool xtalInfo::similarityCompare(const xtalInfo& xtal1, const xtalInfo& xtal2, const double& lenTol, const double& angleTol, const double& posTol)
{
	XcMatrix cell1 = xtal1.get_cell(), cell2 = xtal2.get_cell();
	std::vector<XcVector> pos1 = xtal1.get_pos(), pos2 = xtal2.get_pos();
	std::vector<unsigned int> types1 = xtal1.get_types(), types2 = xtal2.get_types();
	double a1 = xtal1.get_a(), a2 = xtal2.get_a();
	double b1 = xtal1.get_b(), b2 = xtal2.get_b();
	double c1 = xtal1.get_c(), c2 = xtal2.get_c();
	double alpha1 = xtal1.get_alpha(), alpha2 = xtal2.get_alpha();
	double beta1 = xtal1.get_beta(), beta2 = xtal2.get_beta();
	double gamma1 = xtal1.get_gamma(), gamma2 = xtal2.get_gamma();
	//Compare the similarity of lattice parameters
	if (fabs(a1 - a2) > lenTol) return false;
	if (fabs(b1 - b2) > lenTol) return false;
	if (fabs(c1 - c2) > lenTol) return false;
	if (fabs(alpha1 - alpha2) > angleTol) return false;
	if (fabs(beta1 - beta2)  > angleTol) return false;
	if (fabs(gamma1 - gamma2) > angleTol) return false;
	//Compare the similarity of atomic positions
	cell2 = cell1;
	return XtalComp::compare(cell1, types1, pos1, cell2, types2, pos2, NULL, posTol, angleTol);
}