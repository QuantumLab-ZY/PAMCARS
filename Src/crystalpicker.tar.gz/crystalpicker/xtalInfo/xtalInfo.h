#ifndef XTALINFO
#define XTALINFO

#ifdef _WIN32
#include "..\xtalcomp\xtalcomp.h"
#else
#include "../xtalcomp/xtalcomp.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#ifdef _WIN32
#include "..\crystal_utility\structure.h"
#else
#include "../crystal_utility/structure.h"
#endif


class xtalInfo
{
public:
	xtalInfo() {};
	xtalInfo(const crystalInfo& crystal);
	void setFromCrystalInfo(const crystalInfo& crystal);
	~xtalInfo() {};
	//getters
	XcMatrix get_cell() const { return cell; };
	std::vector<XcVector> get_pos() const { return pos; };
	std::vector<unsigned int> get_types() const { return types; };
	double get_a() const { return a; }
	double get_b() const { return b; }
	double get_c() const { return c; }
	double get_alpha() const { return alpha; }
	double get_beta() const { return beta; }
	double get_gamma() const { return gamma; }
	double get_volume() const { return volume; }
	//setters
	void set_cell(const XcMatrix& cell_) { cell = cell_; };
	void set_pos(const std::vector<XcVector>& pos_) { pos = pos_; };
	void set_types(const std::vector<unsigned int>& types_) { types = types_; };
	static bool similarityCompare(const xtalInfo& xtal1, const xtalInfo& xtal2, const double&  lenTol=2.0, const double& angleTol=3.0, const double& posTol=0.4);
	void set_a(const double& a_) { a = a_; }
	void set_b(const double& b_) { b = b_; }
	void set_c(const double& c_) { c = c_; }
	void set_alpha(const double& alpha_) { alpha = alpha_; }
	void set_beta(const double& beta_) { beta = beta_; }
	void set_gamma(const double& gamma_) { gamma = gamma_; }
	void set_volume(const double& volume_) { volume = volume_; }
private:
	XcMatrix cell;
	std::vector<XcVector> pos;
	std::vector<unsigned int> types;
	double a;
	double b;
	double c;
	double alpha;
	double beta;
	double gamma;
	double volume;
};


#endif // !XTALINFO