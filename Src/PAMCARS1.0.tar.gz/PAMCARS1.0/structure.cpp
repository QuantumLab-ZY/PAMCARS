/**********************************************************************
structure.cpp - Custom crystalInfo class for counting chemical bond 
related data in crystals.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/

#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <math.h>
#include <stdlib.h>
#include "structure.h"
#include "utilityFunctions.h"
#include "otherUtilityFunctions.h"
#include "vectorOperations.h"
#include "readOptions.h"
#include "lu.h"

using namespace std;

crystalInfo::crystalInfo():
    a(0.0),
    b(0.0),
    c(0.0),
    Alpha(0.0),
    Beta(0.0),
    Gamma(0.0),
    volume(0.0),
    latticeVectors(lattVec()),
    components(vector<pair<string,int>>()),
    fractionalCoordinates(atom()),
    cartesianCoordinates(atom()),
    energy(0.0),
	poscarTitle("")
{
}

crystalInfo::crystalInfo(const crystalInfo& s){
    a=s.a;
    b=s.b;
    c=s.c;
    Alpha=s.Alpha;
    Beta=s.Beta;
    Gamma=s.Gamma;
    volume=s.volume;
    latticeVectors=s.latticeVectors;
    components=s.components;
    fractionalCoordinates=s.fractionalCoordinates;
    cartesianCoordinates=s.cartesianCoordinates;
    energy=s.energy;
	poscarTitle = s.poscarTitle;
}

crystalInfo& crystalInfo::operator=(const crystalInfo& s){
    if(this!=&s){
        a=s.a;
        b=s.b;
        c=s.c;
        Alpha=s.Alpha;
        Beta=s.Beta;
        Gamma=s.Gamma;
        volume=s.volume;
        latticeVectors=s.latticeVectors;
        components=s.components;
        fractionalCoordinates=s.fractionalCoordinates;
        cartesianCoordinates=s.cartesianCoordinates;
        energy=s.energy;
		poscarTitle = s.poscarTitle;
    }
    return *this;
}

bool crystalInfo::readPoscar(const std::string& filename)
{
	ifstream inPoscar;
	inPoscar.open(filename);
	if (!inPoscar.is_open())
	{
		cout << "Error in " << __FUNCTION__ << ": failed to open '"
			<< filename << "' for reading!\n";
		return false;
	}
	//
	vector<string> tempSplit;
	string temp;
	string inputStr;
	while (getline(inPoscar, temp)) inputStr += (temp + "\n");
	inPoscar.close();
	inputStr = trim(inputStr);
	istringstream lines(inputStr);
	string line;
	//Read the title
	getline(lines, line);
	poscarTitle = trim(line);
	//read scale
	getline(lines, line);
	double scale = stod(trim(line));
	//read latticeVectors
	for (int i = 0; i<3; ++i) 
	{
		getline(lines, line);
		line = trim(line);
		tempSplit = splitMultipleSpaces(line);
		if (tempSplit.size() != 3) {
			cout << "error reading the following line: " << line << endl;
			return false;
		}
		latticeVectors.a[i].x = scale*stod(trim(tempSplit[0]));
		latticeVectors.a[i].y = scale*stod(trim(tempSplit[1]));
		latticeVectors.a[i].z = scale*stod(trim(tempSplit[2]));
	}
	//read components
	//read atomic symbol
	getline(lines, line);
	line = trim(line);
	tempSplit = splitMultipleSpaces(line);
	components.resize(tempSplit.size());
	for (int i = 0; i<tempSplit.size(); ++i)
	{
		components[i].first = trim(tempSplit[i]);
	}
	getline(lines, line);
	line = trim(line);
	tempSplit = splitMultipleSpaces(line);
	for (int i = 0; i<tempSplit.size(); ++i) {
		components[i].second = stoi(trim(tempSplit[i]));
	}
	//Read atomic coordinates
	getline(lines, line);
	line = trim(line);
	if ((line == "Direct") || (line == "direct")) 
	{
		fractionalCoordinates = atom();
		NVECTOR tempVector;//Save the coordinates of an atom
		vector<NVECTOR> tempCoordinates;//Save all coordinates of one type of atoms
		for (int i = 0; i<components.size(); ++i)
		{
			for (int j = 0; j<components[i].second; ++j)
			{
				getline(lines, line);
				line = trim(line);
				tempSplit = splitMultipleSpaces(line);
				tempVector.x = stod(trim(tempSplit[0]));
				tempVector.y = stod(trim(tempSplit[1]));
				tempVector.z = stod(trim(tempSplit[2]));
				tempCoordinates.push_back(tempVector);
			}
			fractionalCoordinates.push_back(tempCoordinates);
			tempCoordinates.clear();
		}
		this->setCartesianCoordinatesFromItsFractionalCoordinates();
	}
	else if ((line == "Cartesian") || (line == "cartesian")) 
	{
		cartesianCoordinates = atom();
		NVECTOR tempVector;//Save the coordinates of an atom
		vector<NVECTOR> tempCoordinates;//Save all coordinates of one type of atoms
		for (int i = 0; i<components.size(); ++i)
		{
			for (int j = 0; j<components[i].second; ++j)
			{
				getline(lines, line);
				line = trim(line);
				tempSplit = splitMultipleSpaces(line);
				tempVector.x = stod(trim(tempSplit[0]));
				tempVector.y = stod(trim(tempSplit[1]));
				tempVector.z = stod(trim(tempSplit[2]));
				tempCoordinates.push_back(tempVector);
			}
			cartesianCoordinates.push_back(tempCoordinates);
			tempCoordinates.clear();
		}
		this->setFractionalCoordinatesFromItsCartesianCoordinates();
	}
	else 
	{
		cout << "error reading the following line: " << line << endl;
		return false;
	}
	a = vec_norm(latticeVectors.a[0]);
	b = vec_norm(latticeVectors.a[1]);
	c = vec_norm(latticeVectors.a[2]);
	//
	Alpha = angle_vec(latticeVectors.a[1], latticeVectors.a[2]);
	Beta = angle_vec(latticeVectors.a[0], latticeVectors.a[2]);
	Gamma = angle_vec(latticeVectors.a[0], latticeVectors.a[1]);
	//
	volume = abs(triple_product(latticeVectors.a[0], latticeVectors.a[1], latticeVectors.a[2]));

	return true;
}

void crystalInfo::writePoscar(const std::string& filename)
{
	ofstream outPoscar;
	outPoscar.open(filename);
	if (!outPoscar.is_open()) {
		cout << "Error in " << __FUNCTION__ << ": failed to open '"
			<< filename << "' for writing!\n";
		return;
	}
	stringstream ss;
	ss << fixed << setprecision(15);
	//
	ss << poscarTitle << "\n"; // Title
	ss << "1.00000\n"; // Scaling factor
	for (int i = 0; i<3; ++i) {
		ss << setw(20) << latticeVectors.a[i].x << "  " << setw(20) << latticeVectors.a[i].y << "  " << setw(20) << latticeVectors.a[i].z << "\n";
	}
	for (int i = 0; i<components.size(); ++i) {
		ss << setw(3) << components[i].first << " ";
	}
	ss << "\n";
	for (int i = 0; i<components.size(); ++i) {
		ss << setw(3) << components[i].second << " ";
	}
	ss << "\n";
	ss << "Direct" << "\n";
	for (int i = 0; i < fractionalCoordinates.size(); ++i) {
		for (int j = 0; j < fractionalCoordinates[i].size(); ++j) {
			ss << setw(20) << fractionalCoordinates[i][j].x << "  " << setw(20) << fractionalCoordinates[i][j].y << "  " << setw(20) << fractionalCoordinates[i][j].z << "\n";
		}
	}
	outPoscar << ss.str();
	outPoscar.close();
}

void crystalInfo::setFromPoscarString(const std::string& poscarString)
{
	string inputStr;
	inputStr = trim(poscarString);
	istringstream lines(inputStr);	
	vector<string> tempSplit;
	string line;
	//Read the title
	getline(lines, line);
	poscarTitle = trim(line);
	//read scale
	getline(lines, line);
	double scale = stod(trim(line));
	//read latticeVectors
	for (int i = 0; i<3; ++i)
	{
		getline(lines, line);
		line = trim(line);
		tempSplit = splitMultipleSpaces(line);
		if (tempSplit.size() != 3) {
			cout << "error reading the following line: " << line << endl;
			return;
		}
		latticeVectors.a[i].x = scale*stod(trim(tempSplit[0]));
		latticeVectors.a[i].y = scale*stod(trim(tempSplit[1]));
		latticeVectors.a[i].z = scale*stod(trim(tempSplit[2]));
	}
	//read components
	//read atomic symbol
	getline(lines, line);
	line = trim(line);
	//tempSplit=split(line,' ');
	tempSplit = splitMultipleSpaces(line);
	components.resize(tempSplit.size());
	for (int i = 0; i<tempSplit.size(); ++i)
	{
		components[i].first = trim(tempSplit[i]);
	}
	getline(lines, line);
	line = trim(line);
	tempSplit = splitMultipleSpaces(line);
	for (int i = 0; i<tempSplit.size(); ++i) {
		components[i].second = stoi(trim(tempSplit[i]));
	}
	//Read atomic coordinates
	getline(lines, line);
	line = trim(line);
	if ((line == "Direct") || (line == "direct"))
	{
		fractionalCoordinates = atom();
		NVECTOR tempVector;//Save the coordinates of an atom
		vector<NVECTOR> tempLatticeVector;//Save all coordinates of one type of atoms
		for (int i = 0; i<components.size(); ++i)
		{
			for (int j = 0; j<components[i].second; ++j)
			{
				getline(lines, line);
				line = trim(line);
				tempSplit = splitMultipleSpaces(line);
				tempVector.x = stod(trim(tempSplit[0]));
				tempVector.y = stod(trim(tempSplit[1]));
				tempVector.z = stod(trim(tempSplit[2]));
				tempLatticeVector.push_back(tempVector);
			}
			fractionalCoordinates.push_back(tempLatticeVector);
			tempLatticeVector.clear();
		}
		this->setCartesianCoordinatesFromItsFractionalCoordinates();
	}
	else if ((line == "Cartesian") || (line == "cartesian"))
	{
		cartesianCoordinates = atom();
		NVECTOR tempVector;//Save the coordinates of an atom
		vector<NVECTOR> tempLatticeVector;//Save all coordinates of one type of atoms
		for (int i = 0; i<components.size(); ++i)
		{
			for (int j = 0; j<components[i].second; ++j)
			{
				getline(lines, line);
				line = trim(line);
				tempSplit = splitMultipleSpaces(line);
				tempVector.x = stod(trim(tempSplit[0]));
				tempVector.y = stod(trim(tempSplit[1]));
				tempVector.z = stod(trim(tempSplit[2]));
				tempLatticeVector.push_back(tempVector);
			}
			cartesianCoordinates.push_back(tempLatticeVector);
			tempLatticeVector.clear();
		}
		this->setFractionalCoordinatesFromItsCartesianCoordinates();
	}
	else
	{
		cout << "error reading the following line: " << line << endl;
		return;
	}
	a = vec_norm(latticeVectors.a[0]);
	b = vec_norm(latticeVectors.a[1]);
	c = vec_norm(latticeVectors.a[2]);
	//
	Alpha = angle_vec(latticeVectors.a[1], latticeVectors.a[2]);
	Beta = angle_vec(latticeVectors.a[0], latticeVectors.a[2]);
	Gamma = angle_vec(latticeVectors.a[0], latticeVectors.a[1]);
	//
	volume = abs(triple_product(latticeVectors.a[0], latticeVectors.a[1], latticeVectors.a[2]));

	return;
}

void crystalInfo::setFractionalCoordinatesFromItsCartesianCoordinates(){
    atom _fractionalCoordinates = cartesianCoordinates;
    vector<double> aa(9);
	vector<double> bb(3);
	vector<int> indx(3);
    double d;
    //
    aa[0] = latticeVectors.a[0].x;//ax
    aa[1] = latticeVectors.a[1].x;//bx
    aa[2] = latticeVectors.a[2].x;//cx
    //
    aa[3] = latticeVectors.a[0].y;//ay
    aa[4] = latticeVectors.a[1].y;//by
    aa[5] = latticeVectors.a[2].y;//cy
    //
    aa[6] = latticeVectors.a[0].z;//az
    aa[7] = latticeVectors.a[1].z;//bz
    aa[8] = latticeVectors.a[2].z;//cz
    //
	ludcmp(&aa[0], 3, &indx[0], &d);
    //
    for(int i=0;i<cartesianCoordinates.size();++i){
        for(int j=0;j<cartesianCoordinates[i].size();++j){
            //
            bb[0] = cartesianCoordinates[i][j].x;
            bb[1] = cartesianCoordinates[i][j].y;
            bb[2] = cartesianCoordinates[i][j].z;
            //
			lubksb(&aa[0], 3, &indx[0], &bb[0]);
            //Change atomic coordinates beyond the unit cell back into 
			//the unit cell through periodic boundary conditions.
			for (int k = 0; k < 3; ++k) {
				while (bb[k] < 0.0 || bb[k] >= 1.0) {
					if (bb[k] < 0.0) bb[k] += 1.0;
					if (bb[k] >= 1.0) bb[k] -= 1.0;
                }//while
            }//k
            _fractionalCoordinates[i][j].x = bb[0];
            _fractionalCoordinates[i][j].y = bb[1];
            _fractionalCoordinates[i][j].z = bb[2];
        }//j
    }//i
    fractionalCoordinates = _fractionalCoordinates;
}

void crystalInfo::setCartesianCoordinatesFromItsFractionalCoordinates(){
    atom _cartesianCoordinates = fractionalCoordinates;
	for (int i = 0; i < fractionalCoordinates.size(); ++i){
		for (int j = 0; j < fractionalCoordinates[i].size(); ++j){
			_cartesianCoordinates[i][j].x = fractionalCoordinates[i][j].x*latticeVectors.a[0].x + fractionalCoordinates[i][j].y*latticeVectors.a[1].x
				                          + fractionalCoordinates[i][j].z*latticeVectors.a[2].x;
			//
			_cartesianCoordinates[i][j].y = fractionalCoordinates[i][j].x*latticeVectors.a[0].y + fractionalCoordinates[i][j].y*latticeVectors.a[1].y
				                          + fractionalCoordinates[i][j].z*latticeVectors.a[2].y;
			//
			_cartesianCoordinates[i][j].z = fractionalCoordinates[i][j].x*latticeVectors.a[0].z + fractionalCoordinates[i][j].y*latticeVectors.a[1].z
				                          + fractionalCoordinates[i][j].z*latticeVectors.a[2].z;
		}//j
	}//i
    cartesianCoordinates = _cartesianCoordinates;
}

double crystalInfo::get_atomicDistance(const string& name1,const int& number1,const string& name2,const int& number2){
    int i;
    int j;
    for(i=0;i<components.size();++i){
        if(name1==components[i].first) break;
    }
    if(i==components.size()){
        cout<<name1<<" does not exist in the crystal!"<<endl;
        return -1.0;
    }
    for(j=0;j<components.size();++j){
        if(name2==components[j].first) break;
    }
    if(j==components.size()){
        cout<<name2<<" does not exist in the crystal!"<<endl;
        return -1.0;
    }
    return Ndistance(cartesianCoordinates[i][number1],cartesianCoordinates[j][number2]);
}

double crystalInfo::get_atomicDistance(const int& type1,const int& number1,const int& type2,const int& number2){
    return Ndistance(cartesianCoordinates[type1][number1],cartesianCoordinates[type2][number2]);
}



