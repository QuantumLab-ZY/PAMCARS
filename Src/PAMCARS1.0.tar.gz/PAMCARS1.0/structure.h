/**********************************************************************
structure.h - Custom crystalInfo class for counting chemical bond 
related data in crystals.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/

#ifndef STRUCTURE_H
#define STRUCTURE_H

#include <string>
#include <vector>
#include "vectorOperations.h"
#include "readOptions.h"


typedef std::vector<std::vector<NVECTOR>> atom;

class crystalInfo {
private:
    double a;
    double b;
    double c;
    double Alpha;
    double Beta;
    double Gamma;
    double volume;
    lattVec latticeVectors;
    std::vector<std::pair<std::string,int>> components;
    atom fractionalCoordinates;
    atom cartesianCoordinates;
    double energy;
	std::string poscarTitle;
 public:
    explicit crystalInfo();
    crystalInfo(const crystalInfo& s);
    crystalInfo& operator=(const crystalInfo& s);
    //Getters
    double get_a() const {return a;}
    double get_b() const {return b;}
    double get_c() const {return c;}
    double get_alpha() const {return Alpha;}
    double get_beta() const {return Beta;}
    double get_gamma() const {return Gamma;}
    double get_volume() const {return volume;}
    lattVec get_latticeVectors() const {return latticeVectors;}
    std::vector<std::pair<std::string,int>> get_components() const {return components;}
    atom get_fractionalCoordinates() const {return fractionalCoordinates;}
    atom get_cartesianCoordinates() const {return cartesianCoordinates;}
    double get_energy() const {return energy;}
	std::string get_poscarTitle() const { return poscarTitle; }
    //Setters
	bool readPoscar(const std::string& filename);
	void writePoscar(const std::string& filename);
	void setFromPoscarString(const std::string& poscarString);
    void set_a(const double& _a) {a = _a;}
    void set_b(const double& _b) {b = _b;}
    void set_c(const double& _c) {c = _c;}
    void set_Alpha(const double& _Alpha) {Alpha = _Alpha;}
    void set_Beta(const double& _Beta) {Beta = _Beta;}
    void set_Gamma(const double& _Gamma) {Gamma = _Gamma;}
    void set_volume(const double& _volume) {volume = _volume;}
    void set_latticeVectors(const lattVec& var) {latticeVectors = var;}
    void set_components(const std::vector<std::pair<std::string,int>>& si) {components = si;}
    void set_fractionalCoordinates(const atom& s) {fractionalCoordinates = s;}
    void set_cartesianCoordinates(const atom& s) {cartesianCoordinates = s;}
	void set_energy(const double& _energy) { energy = _energy; }
	void set_poscarTitle(const std::string& _poscarTitle) { poscarTitle = _poscarTitle; }
    //
    double get_atomicDistance(const std::string& name1,const int& number1,const std::string& name2,const int& number2);
    double get_atomicDistance(const int& type1,const int& number1,const int& type2,const int& number2);
 protected:
    //bool creatLatticeVectors();
    void setFractionalCoordinatesFromItsCartesianCoordinates();
    void setCartesianCoordinatesFromItsFractionalCoordinates();
};


#endif // STRUCTURE_H
