/**********************************************************************
readOptions.h - Read parameters in Iterations.in
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/


#ifndef READOPTION
#define READOPTION
//
#include <string>
#include <vector>
#include <tuple>

//
class readOptions{
private:
	std::vector<std::vector<std::pair<std::pair<std::string, std::string>, double>>> bondingPairs;
	std::vector<std::pair<std::pair<std::string, std::string>, double>> minDistanceOfAtoms;
    bool m_optionsAreValid;
	std::string m_filename;
	double defaultMinDistanceOfAtoms;
	int periodicalRange;
	int maxAttemptsToGenerateInitialCrystal;
	//
	std::vector<int> numOfIterations;
	double delta_a;
	double delta_b;
	double delta_c;
	double delta_Alpha;
	double delta_Beta;
	double delta_Gamma;
	std::vector<std::pair<std::string, double>> maxDisplacementOfAtoms;
	double defaultMaxDisplacementOfAtoms;
	std::vector<std::pair<std::pair<std::string, std::string>, int>> maxNumOfSharedVertexes;
	std::vector<std::pair<std::string, int>> maxCoordinationNum;
	//2019.3.6
	int numOfTrialCrystals;
	int sizeOfTheSetsOfIterationStartCriteria;
	bool skipIfTheSetOfIterationStartCriteriaIsEmpty;
	std::vector<std::pair<std::string, std::vector<std::pair<std::string, int>>>> maxNumOfAtomsOnPolyhedron;
	bool useIterationStartCriteria;
public:
    explicit readOptions();
    readOptions& operator=(const readOptions& s);
    readOptions(const readOptions& s);
	static readOptions readInput(const std::string& filename);
    static readOptions readOptionsFromCharArray(const char* input,
		                                        std::string filename = "");
	void interpretLineAndSetOption(std::string line);
    //string getOptionsString() const;
    bool optionsAreValid() const {return m_optionsAreValid;};
    //Getters
	std::vector<std::vector<std::pair<std::pair<std::string, std::string>, double>>> get_bondingPairs() const { return bondingPairs; }
	std::vector<std::pair<std::pair<std::string, std::string>, double>> get_minDistanceOfAtoms() const { return minDistanceOfAtoms; }
	std::string get_filename() const { return m_filename; }
	double get_defaultMinDistanceOfAtoms() const { return defaultMinDistanceOfAtoms; }
	int get_periodicalRange() const { return periodicalRange; }
	std::vector<int> get_numOfIterations() const { return numOfIterations; }
	std::vector<std::pair<std::pair<std::string, std::string>, int>> get_maxNumOfSharedVertexes() const { return maxNumOfSharedVertexes; }
	std::vector<std::pair<std::string, int>> get_maxCoordinationNum() const { return maxCoordinationNum; }
	int get_numOfTrialCrystals() const { return numOfTrialCrystals; }
	int get_sizeOfTheSetsOfIterationStartCriteria() const { return sizeOfTheSetsOfIterationStartCriteria; }
	int get_maxAttemptsToGenerateInitialCrystal() const { return maxAttemptsToGenerateInitialCrystal; }
	std::vector<std::pair<std::string, std::vector<std::pair<std::string, int>>>> get_maxNumOfAtomsOnPolyhedron() const { return maxNumOfAtomsOnPolyhedron; }
	bool get_useIterationStartCriteria() const { return useIterationStartCriteria; };
	//
	double get_delta_a() const { return delta_a; }
	double get_delta_b() const { return delta_b; }
	double get_delta_c() const { return delta_c; }
	double get_delta_Alpha() const { return delta_Alpha; }
	double get_delta_Beta() const { return delta_Beta; }
	double get_delta_Gamma() const { return delta_Gamma; }
	std::vector<std::pair<std::string, double>> get_maxDisplacementOfAtoms() const { return maxDisplacementOfAtoms; }
	double get_defaultMaxDisplacementOfAtoms() const { return defaultMaxDisplacementOfAtoms; }
	bool get_skipIfTheSetOfIterationStartCriteriaIsEmpty() const { return skipIfTheSetOfIterationStartCriteriaIsEmpty; }
	// Setters
	void set_bondingPairs(const std::vector<std::vector<std::pair<std::pair<std::string, std::string>, double>>>& s) { bondingPairs = s; }
	void set_minDistanceOfAtoms(const std::vector<std::pair<std::pair<std::string, std::string>, double>>& s) { minDistanceOfAtoms = s; }
	void set_filename(const std::string& s) { m_filename = s; }
	void set_defaultMinDistanceOfAtoms(const double& var) { defaultMinDistanceOfAtoms = var; }
	void set_periodicalRange(const int& var) { periodicalRange = var; }
	void set_numOfIterations(const std::vector<int>& var) { numOfIterations = var; }
	//
	void set_delta_a(const double& var) { delta_a = var; }
	void set_delta_b(const double& var) { delta_b = var; }
	void set_delta_c(const double& var) { delta_c = var; }
	void set_delta_Alpha(const double& var) { delta_Alpha = var; }
	void set_delta_Beta(const double& var) { delta_Beta = var; }
	void set_delta_Gamma(const double& var) { delta_Gamma = var; }
	void set_maxDisplacementOfAtoms(const std::vector<std::pair<std::string, double>>& var) { maxDisplacementOfAtoms = var; }
	void set_defaultMaxDisplacementOfAtoms(const double& var) { defaultMaxDisplacementOfAtoms = var; }
	void set_maxNumOfSharedVertexes(const std::vector<std::pair<std::pair<std::string, std::string>, int>>& var) { maxNumOfSharedVertexes = var; }
	void set_maxCoordinationNum(const std::vector<std::pair<std::string, int>>& var) { maxCoordinationNum = var; }
	void set_numOfTrialCrystals(const int& var) { numOfTrialCrystals = var; }
	void set_sizeOfTheSetsOfIterationStartCriteria(const int& var) { sizeOfTheSetsOfIterationStartCriteria = var; }
	void set_maxAttemptsToGenerateInitialCrystal(const int& var) { maxAttemptsToGenerateInitialCrystal = var; }
	void set_skipIfTheSetOfIterationStartCriteriaIsEmpty(const bool& var) { skipIfTheSetOfIterationStartCriteriaIsEmpty = var; }
	void set_maxNumOfAtomsOnPolyhedron(const std::vector<std::pair<std::string, std::vector<std::pair<std::string, int>>>>& var) { maxNumOfAtomsOnPolyhedron = var; }
	void set_useIterationStartCriteria(const bool& var) { useIterationStartCriteria = var; }
};
#endif
