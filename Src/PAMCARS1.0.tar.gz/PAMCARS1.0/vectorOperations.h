/**********************************************************************
vectorOperations.h - A custom class for 3-D vector operations. 
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/


#ifndef VECTOROPERATIONS_H
#define VECTOROPERATIONS_H

struct NVECTOR{
    double x;
    double y;
    double z;
    NVECTOR():x(0.0),y(0.0),z(0.0){}
    NVECTOR(double _x,double _y,double _z):x(_x),y(_y),z(_z){}
    NVECTOR(const NVECTOR& vec){
        x=vec.x;
        y=vec.y;
        z=vec.z;
    }
    NVECTOR& operator=(const NVECTOR& vec)
    {
        if(this!=&vec){
            x=vec.x;
            y=vec.y;
            z=vec.z;
        }
        return *this;
    }
};

struct lattVec{
    NVECTOR a[3];
    lattVec(){
        a[0]=NVECTOR();
        a[1]=NVECTOR();
        a[2]=NVECTOR();
    }
    lattVec(NVECTOR _a,NVECTOR _b,NVECTOR _c){
        a[0]=_a;
        a[1]=_b;
        a[2]=_c;
    }
    lattVec& operator=(const lattVec& vec)
    {
        if(this!=&vec){
            a[0]=vec.a[0];
            a[1]=vec.a[1];
            a[2]=vec.a[2];
        }
        return *this;
    }
};

NVECTOR operator+(const NVECTOR& a,const NVECTOR& b);

NVECTOR operator-(const NVECTOR& a,const NVECTOR& b);

NVECTOR operator*(const int& a, const NVECTOR& b);

NVECTOR operator*(const double& a, const NVECTOR& b);

double dot(const NVECTOR& a,const NVECTOR& b);

NVECTOR crossdot(const NVECTOR& a,const NVECTOR& b);

double vec_norm(const NVECTOR& a);

double angle_vec(const NVECTOR& a,const NVECTOR& b);

double Ndistance(const NVECTOR& a,const NVECTOR& b);

double triple_product(const NVECTOR& a,const NVECTOR& b,const NVECTOR& c);

#endif // VECTOROPERATIONS_H
