/**********************************************************************
miniVector.h - An inherited class of vector
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/


#ifndef MINIVECTOR_H
#define MINIVECTOR_H

#include <vector>

class miniVector : public std::vector<int>
{
public:
	bool push_back(const int& var);
	//
	void initialMaxSize(const int& maxSize_);
	//
	explicit miniVector(const int& maxSize_);
	//
	miniVector operator+(const std::vector<int>& var);
private:
	int maxSize;
	//
	int seqSearch(const int arr[], int first, int last, int target)
	{
		int i;
		// scan indices in the range first <= i < last
		for (i = first; i < last; i++)
			if (arr[i] == target)
				return i;				// immediately return on a match

		return last;					// return last if target not found
	}
	//
	void selectionSort(int arr[], int n)
	{
		int smallIndex; // index of smallest element in the sublist
		int pass, j;
		int temp;

		// pass has the range 0 to n-2
		for (pass = 0; pass < n - 1; pass++)
		{
			// scan the sublist starting at index pass
			smallIndex = pass;

			// j traverses the sublist arr[pass+1] to arr[n-1]
			for (j = pass + 1; j < n; j++)
				// update if smaller element found
				if (arr[j] < arr[smallIndex])
					smallIndex = j;

			// if smallIndex and pass are not the same location,
			// exchange the smallest item in the sublist with arr[pass]
			if (smallIndex != pass)
			{
				temp = arr[pass];
				arr[pass] = arr[smallIndex];
				arr[smallIndex] = temp;
			}
		}
	}
};
//
miniVector::miniVector(const int& maxSize_) :std::vector<int>(), maxSize(maxSize_) { }

void miniVector::initialMaxSize(const int& maxSize_) { maxSize = maxSize_; }

bool miniVector::push_back(const int& var)
{
	if (maxSize <= 0)
	{
		return true;
	}
	else
	{
		if (size() == 0)
		{
			std::vector<int>::push_back(var);
			return true;
		}
		else
		{
			if (size() < maxSize)
			{
				//If there is no var in miniVector
				if (seqSearch(&front(), 0, size(), var) == size())
				{
					std::vector<int>::push_back(var);
					selectionSort(&front(), size());
					return true;
				}
				//If miniVector contains var
				else
				{
					return true;
				}
			}
			else
			{
				if (var >= front())
				{
					//If there is no var in miniVector
					if (seqSearch(&front(), 0, size(), var) == size())
					{
						front() = var;
						selectionSort(&front(), size());
						return true;
					}
					//If miniVector contains var
					else
					{
						return true;
					}
				}
				else
				{
					return false;
				}
			}
		}
	}
}

miniVector miniVector::operator+(const std::vector<int>& var)
{
	for (size_t i = 0; i < var.size(); i++)
	{
		push_back(var[i]);
	}
	return *this;
}

#endif