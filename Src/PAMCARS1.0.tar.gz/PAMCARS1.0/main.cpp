/*****************************************************************************
main.cpp - Main function for PAMCARS(PAuling rules guided Monte CARlo Search).
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
******************************************************************************/

// For timings
#include <chrono>
// To remove the log file
#include <cstdio>
#include <iostream>
#include <sstream>
#include "mpi.h"

#include "elemInfo.h"
#include "fileSystemUtils.h"
#include "randSpg.h"
#include "randSpgOptions.h"
#include "utilityFunctions.h"
//
#include "randSpgCombinatorics.h"
#include "otherUtilityFunctions.h"
//
#include "structure.h"
#include "countBonds.h"
//
#include "miniVector.h"
#include "soft_info.h"

using namespace std;


int main(int argc, char* argv[])
{
	//Initialize the mpi environment
	int my_rank, group_size;
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &group_size);
	MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

	//Two input files to be read
	string rstructFileName = "Rcrystal.in";
	string iterationsFileName = "Iterations.in";
	RandSpgOptions options = RandSpgOptions::readOptions(rstructFileName);
	readOptions iterationOptions = readOptions::readInput(iterationsFileName);

	if ((!options.optionsAreValid())||(!iterationOptions.optionsAreValid())) {
		if (my_rank == 0)
		{
			cout << "Warning: the options that were received are invalid\n";
			cout << "Please go back and check them.\n";
		}
		MPI_Finalize();
		exit(EXIT_FAILURE);
	}

	// Write information to .out file
	string outFileName = "PAMCARS.out";
	if (my_rank == 0)
	{
		// If there are old .log files and .out files here, remove it
		remove(outFileName.c_str());
		remove(e_logfilename.c_str());
		//Print the logo of PAMCARS to .out file
		appendToLogFile(outFileName, softInfo());
	}

	vector<uint> atoms;

	string comp = options.getComposition();

	if (!ElemInfo::readComposition(comp, atoms)) {
		cout << "Error: Composition, " << comp << ", is an invalid composition.\n";
		MPI_Finalize();
		exit(EXIT_FAILURE);
	}

	// Set up lattice mins and maxes
	latticeStruct mins = options.getLatticeMins();
	latticeStruct maxes = options.getLatticeMaxes();

	// Create the input
	randSpgInput input(1, atoms, mins, maxes);

	// Add various other input options
	input.IADScalingFactor = options.getScalingFactor();
	input.minRadius = options.getMinRadii();
	input.manualAtomicRadii = options.getRadiusVector();
	input.customMinIADs = options.getCustomMinIADs();
	input.minVolume = options.getMinVolume();
	input.maxVolume = options.getMaxVolume();
	input.forcedWyckAssignments = options.getForcedWyckAssignments();
	input.verbosity = options.getVerbosity();
	input.maxAttempts = options.getMaxAttempts();
	input.forceMostGeneralWyckPos = options.forceMostGeneralWyckPos();

	// Set up various other options
	vector<uint> spacegroups = options.getSpacegroups();
	int numOfEach = options.getNumOfEachSpgToGenerate();
	string outDir = options.getOutputDir();
	//
	int maxAttemptsToGenerateInitialCrystal = iterationOptions.get_maxAttemptsToGenerateInitialCrystal();

#ifdef _WIN32
	outDir += "\\";
#else
	outDir += "/";
#endif

	// Defined in fileSystemUtils.h
	mkDir(outDir);
	//
	vector<vector<pair<pair<string, string>, double>>> bondingPairs = iterationOptions.get_bondingPairs();
	//Merge input parameters of chemical bond lengths
	vector<pair<pair<string, string>, double>> globalBondingPairs;
	for (size_t ii = 0; ii < bondingPairs.size(); ii++)
	{
		for (size_t jj = 0; jj < bondingPairs[ii].size(); jj++)
		{
			globalBondingPairs.push_back(bondingPairs[ii][jj]);
		}
	}

	//Initialize the setsOfIterationStartCriteriaOfAllSpacegroups.
	//��setsOfIterationStartCriteriaOfAllSpacegroups�� stores ��setOfIterationStartCriteria�� of each space group.
	//��setOfIterationStartCriteria�� stores ��sizeOfTheSetsOfIterationStartCriteria�� different maximum number of 
	//chemical bonds in ��numOfTrialCrystals�� random crystal structures.The number of chemical bonds in the initial 
	//crystal structures used for MC iteration must be higher than the smallest number of chemical bonds in 
	//��setOfIterationStartCriteria��for each space group.
	vector<miniVector> setsOfIterationStartCriteriaOfAllSpacegroups;
	if (iterationOptions.get_useIterationStartCriteria())
	{
		if (my_rank == 0)
		{
			stringstream info;
			info << "======================================================================================\n"
				 << "The pragram is initializing the sets of iteration start criteria for all space groups:\n";
			appendToLogFile(outFileName, info.str());
		}
		MPI_Barrier(MPI_COMM_WORLD);
		for (size_t i = 0; i < spacegroups.size(); i++)
		{
			miniVector setOfIterationStartCriteria(iterationOptions.get_sizeOfTheSetsOfIterationStartCriteria());
			uint spg = spacegroups[i];
			do
			{
				try
				{
					// Change the input spg to have the right spacegroup
					input.spg = spg;
					//
					int numOfTrialCrystals = iterationOptions.get_numOfTrialCrystals();
					//
					for (size_t j = 0; j < numOfTrialCrystals; j++)
					{
						if (j % group_size == my_rank)
						{
							atomAssignments assignmentsForRstruct;
							vector<atomStruct> wyckoffAtomsForRstruct;
							Crystal rcrystal;
							rcrystal = RandSpg::generateCrystalForRandomAtomAssignments(input, assignmentsForRstruct, wyckoffAtomsForRstruct, iterationOptions);
							//
							if (rcrystal.getVolume() == 0)
							{
								//failed!
								continue;
							}
							else
							{
								string poscarString = rcrystal.getPOSCARString("rstruct");
								crystalInfo rstruct;
								rstruct.setFromPoscarString(poscarString);
								setOfIterationStartCriteria.push_back(countChemicalBonds(rstruct, iterationOptions, globalBondingPairs));
							}
						}//if
					}//j
					 //Non-zero processes
					if (my_rank != 0)
					{
						//Non-zero processes send setOfIterationStartCriteria to process 0
						MPI_Request req;
						MPI_Status status;
						int tag1 = 111;
						int tag2 = 222;
						int size = setOfIterationStartCriteria.size();
						MPI_Isend(&size, 1, MPI_INT, 0, tag1, MPI_COMM_WORLD, &req);
						MPI_Wait(&req, &status);
						//If size is not 0, send setOfIterationStartCriteria to process 0
						if (size != 0)
						{
							MPI_Isend(&setOfIterationStartCriteria[0], size, MPI_INT, 0, tag2, MPI_COMM_WORLD, &req);
							MPI_Wait(&req, &status);
						}
					}
					//process 0
					else
					{
						//Process 0 receives size parameters from other processes
						vector<MPI_Request> reqList(group_size - 1);
						vector<MPI_Status> statusList(group_size - 1);
						vector<int> sizeList(group_size);
						int tag1 = 111;
						int tag2 = 222;
						sizeList[0] = setOfIterationStartCriteria.size();
						for (int ii = 1; ii < group_size; ii++)
						{
							MPI_Irecv(&sizeList[ii], 1, MPI_INT, ii, tag1, MPI_COMM_WORLD, &reqList[ii - 1]);
						}
						if (group_size > 1)
						{
							MPI_Waitall(group_size - 1, &reqList[0], &statusList[0]);
						}
						//Process 0 receives setOfIterationStartCriteria from other processes
						//which have a nonempty setOfIterationStartCriteria.
						int numOfNonzeroProcessesWithNonemptySet = 0;
						for (size_t i = 1; i < group_size; i++)
						{
							if (sizeList[i] != 0)
							{
								numOfNonzeroProcessesWithNonemptySet++;
							}
						}
						vector<MPI_Request> reqList2(numOfNonzeroProcessesWithNonemptySet);
						vector<MPI_Status> statusList2(numOfNonzeroProcessesWithNonemptySet);
						//tempVector is used to save the setOfIterationStartCriteria 
						//received by process 0 from other processes.
						vector<vector<int>> tempVector(numOfNonzeroProcessesWithNonemptySet);
						int location = 0;
						for (int ii = 1; ii < group_size; ii++)
						{
							if (sizeList[ii] != 0)
							{
								tempVector[location].resize(sizeList[ii]);
								MPI_Irecv(&tempVector[location][0], sizeList[ii], MPI_INT, ii, tag2, MPI_COMM_WORLD, &reqList2[location]);
								location++;
							}
						}
						if (group_size > 1)
						{
							MPI_Waitall(numOfNonzeroProcessesWithNonemptySet, &reqList2[0], &statusList2[0]);
						}
						//process 0 gathers setOfIterationStartCriteria of all processes
						for (size_t ii = 0; ii < numOfNonzeroProcessesWithNonemptySet; ii++)
						{
							setOfIterationStartCriteria + tempVector[ii];
						}
					}
					//Process 0 broadcasts the data in setOfIterationStartCriteria
					int globalSizeOfsetOfIterationStartCriteria = setOfIterationStartCriteria.size();
					MPI_Bcast(&globalSizeOfsetOfIterationStartCriteria, 1, MPI_INT, 0, MPI_COMM_WORLD);
					if (globalSizeOfsetOfIterationStartCriteria != 0)
					{
						setOfIterationStartCriteria.resize(globalSizeOfsetOfIterationStartCriteria);
						//Wait for setOfIterationStartCriteria of all processes to be ready
						MPI_Barrier(MPI_COMM_WORLD);
						MPI_Bcast(&setOfIterationStartCriteria[0], globalSizeOfsetOfIterationStartCriteria, MPI_INT, 0, MPI_COMM_WORLD);
					}
				}
				catch (turnToNextSpgSignal)
				{
					break;
				}
			} while (0);
		    setsOfIterationStartCriteriaOfAllSpacegroups.push_back(setOfIterationStartCriteria);
			if (my_rank == 0)
			{
				stringstream info;
				info << "The pragram has initialized the set of iteration start criteria for space group " << spg << " !\n";
				appendToLogFile(outFileName, info.str());
			}
		}//i
		if (my_rank == 0)
		{
			stringstream info;
			info << "The pragram has initialized the sets of iteration start criteria for all space groups!\n"
				 << "======================================================================================\n";
			appendToLogFile(outFileName, info.str());
		}
	}
	//The MC iterations start!
	if (my_rank == 0)
	{
		stringstream info;
		info << "===========================The MC iterations have started!============================\n";
		appendToLogFile(outFileName, info.str());
	}
	MPI_Barrier(MPI_COMM_WORLD);
	for (int i = 0; i < spacegroups.size(); i++)
	{
		if (iterationOptions.get_useIterationStartCriteria())
		{
			if (iterationOptions.get_skipIfTheSetOfIterationStartCriteriaIsEmpty())
			{
				if (setsOfIterationStartCriteriaOfAllSpacegroups[i].size() == 0)
				{
					continue;//Skip to the next space group
				}
			}
		}
		uint spg = spacegroups[i];
		// Change the input spg to have the right spacegroup
		input.spg = spg;
		//Generate numOfEach random structures for the space group spg
		try
		{
			for (size_t j = 0; j < numOfEach; j++)
			{
				int fileIndex = i*numOfEach + j + 1;
				int fileNumber = j + 1;
				string filename = outDir + comp + "_" + to_string(spg) + "-" + to_string(fileNumber) + ".vasp";
				if (fileIndex % group_size == my_rank)
				{
					Crystal pcrystal;
					//assignmentsForPcrystal stores the Wyckoff information of pcrystal.
					atomAssignments assignmentsForPcrystal;
					//wyckoffAtomsForPstruct stores the Wyckoff sites of each atom in pcrystal.
					vector<atomStruct> wyckoffAtomsForPcrystal;
					//numOfBondsForPcrystal stores the number of chemical bonds of each group of coordinated polyhedrons.
					vector<int> numOfBondsForPcrystal;

					//Generate eligible initial random structures
					try
					{
						for (size_t k = 0; k < max(1, maxAttemptsToGenerateInitialCrystal); k++)
						{
							pcrystal = RandSpg::generateCrystalForRandomAtomAssignments(input, assignmentsForPcrystal, wyckoffAtomsForPcrystal, iterationOptions);
							if (pcrystal.getVolume() == 0)
							{
								//failed!
								if (k == max(1, maxAttemptsToGenerateInitialCrystal) - 1)
								{
									throw ++k;
								}
								continue;
							}
							else//succeed
							{
								//Use iteration start criteria to check pcrystal.
								//The number of chemical bonds in pcrystal must exceed the smallest
								//number of chemical bonds in setsOfIterationStartCriteriaOfAllSpacegroups[i]
								//before it can be used for MC iteration.
								if (iterationOptions.get_useIterationStartCriteria())
								{
									string poscarString = pcrystal.getPOSCARString("initial_pcrystal");
									crystalInfo initial_pstruct;
									initial_pstruct.setFromPoscarString(poscarString);
									int numOfBondsForInitialStruct = countChemicalBonds(initial_pstruct, iterationOptions, globalBondingPairs);
									if (setsOfIterationStartCriteriaOfAllSpacegroups[i].push_back(numOfBondsForInitialStruct))
									{
										//pcrystal is eligible.
										break;
									}
									else
									{
										if (k == max(1, maxAttemptsToGenerateInitialCrystal) - 1)
										{
											throw ++k;
										}
										//generate a new pcrystal
										continue;
									}
								}
								//useIterationStartCriteria switch is turned off.
								//pcrystal can be used for MC iteration directly.
								else
								{
									break;
								}
							}
						}//k
					}
					catch (const size_t& k)
					{
						if (k == max(1, maxAttemptsToGenerateInitialCrystal))
						{
							//failed to Generate an eligible initial random structure after 
							//maxNumOfTrialsToGenerateInitialCrystal attempts.
							continue;//skip to j+1
						}
					}
					//Number of successive iterations for each group of coordinated polyhedrons
					vector<int> numberOfIterations = iterationOptions.get_numOfIterations();
					for (int m = 0; m < numberOfIterations.size(); m++)
					{
						string title = comp + " -- File No." + to_string(fileNumber) + " with spg of: " + to_string(spg);
						string poscarString = pcrystal.getPOSCARString(title);
						crystalInfo pstruct;
						pstruct.setFromPoscarString(poscarString);
						//store the number of the chemical bonds of the coordinated polyhedrons in group m
						numOfBondsForPcrystal.push_back(countChemicalBonds(pstruct, iterationOptions, bondingPairs[m]));
						//perform numberOfIterations[m] MC iterations for the coordinated polyhedrons
						//in the group m.
						for (int l = 0; l < numberOfIterations[m]; l++)
						{
							try
							{
								//tempWyckoffAtomsForPstruct will be changed when the following function is called.
								vector<atomStruct> tempWyckoffAtomsForPcrystal = wyckoffAtomsForPcrystal;
								Crystal c = RandSpg::crystalIterator(input, assignmentsForPcrystal, iterationOptions, pcrystal, tempWyckoffAtomsForPcrystal);

								//Check if the number of chemical bonds in the coordinated polyhedrons from 
								//the first group to the current group has been increased.

								//numOfBondsForRcrystal Save the number of chemical bonds in MC iterated pcrystal.
								vector<int> numOfBondsForRcrystal;
								for (size_t n = 0; n < numOfBondsForPcrystal.size(); n++)
								{
									string title = comp + " -- File No." + to_string(fileNumber) + " with spg of: " + to_string(spg);
									string poscarString = c.getPOSCARString(title);
									crystalInfo rstruct;
									rstruct.setFromPoscarString(poscarString);
									int numOfBondsForGroupN = countChemicalBonds(rstruct, iterationOptions, bondingPairs[n]);
									numOfBondsForRcrystal.push_back(numOfBondsForGroupN);
									//
									if (numOfBondsForGroupN < numOfBondsForPcrystal[n])
									{
										throw nextCycleSignal();
									}
									if (n == numOfBondsForPcrystal.size() - 1)
									{
										//A MC iterated crystal has been created successfully.
										//update pcrystal,wyckoffAtomsForPcrystal and numOfBondsForPcrystal.
										pcrystal = c;
										wyckoffAtomsForPcrystal = tempWyckoffAtomsForPcrystal;
										for (size_t r = 0; r < numOfBondsForPcrystal.size(); r++)
										{
											numOfBondsForPcrystal[r] = numOfBondsForRcrystal[r];
										}
									}
								}//n									
							}//try
							catch (nextCycleSignal)
							{
								// We failed!
								continue;
							}
						}//l
					}//m
					 //optput pcrystal
					if (pcrystal.getVolume() != 0)
					{
						// Success!
						string title = comp + " -- File No." + to_string(fileNumber) + " with spg of: " + to_string(spg);
						pcrystal.writePOSCAR(filename, title);
						string datFilename = outDir + "atomAssignments_" + to_string(spg) + "-" + to_string(fileNumber) + ".dat";
						printAtomAssignmentsToDatFile(assignmentsForPcrystal, datFilename);
					}
				}
			}//j
			stringstream info;
			info << "Process " << my_rank << ":" << " The MC iterations for space group " << spg << " has been finnished.\n"
				<< "--------------------------------------------------------------------------------------\n";
			appendToLogFile(outFileName, info.str());
		}
		catch (turnToNextSpgSignal)
		{
			stringstream info;
			info << "Process " << my_rank << ":" << " This spg '" << spg << "' cannot be generated with this composition!\n"
				<< "--------------------------------------------------------------------------------------\n";
			appendToLogFile(outFileName, info.str());
			continue;
		}
	}//i
	MPI_Barrier(MPI_COMM_WORLD);
	if (my_rank == 0)
	{
		string text = "==========================The MC iterations have finished!============================\n";
		appendToLogFile(outFileName, text);
	}
	MPI_Finalize();
	return 0;
}
