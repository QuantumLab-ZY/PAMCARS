#ifndef OTHER_UTILITY_FUNCTIONS_H
#define OTHER_UTILITY_FUNCTIONS_H
//
#include <sstream>
#include <fstream>
#include <vector>
#include <iostream>
#include "randSpg.h"
#ifdef _WIN32
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#else
#include <algorithm>
#endif

static void printAtomAssignmentsToDatFile(const atomAssignments& atomAss, const std::string& datFilename)
{
	std::stringstream ss;
	ss << RandSpg::getAtomAssignmentsString(atomAss);
	std::ofstream outFile;
	outFile.open(datFilename);
	if (!outFile.is_open())
	{
		std::cout << "Error in " << __FUNCTION__ << ": failed to open '"
			<< datFilename << "' for writing!\n";
		return;
	}
	outFile << ss.str();
	outFile.close();
}

class nextCycleSignal{};

class turnToNextSpgSignal{};
//
static std::vector<std::string> splitMultipleSpaces(const std::string& s)
{
	std::vector<std::string> tempSplit = split(s, ' ');
	std::vector<std::string> finalSplit;
	for (int i = 0; i<tempSplit.size(); ++i) {
		if (trim(tempSplit[i]) != "") finalSplit.push_back(tempSplit[i]);
	}
	return finalSplit;
}

static void appendToLogFile(const std::string& filename, const std::string& text)
{
	std::fstream fs;
	fs.open(filename, std::fstream::out | std::fstream::app);
	if (!fs.is_open()) {
		std::cout << "Error opening log file, " << filename << ".\n"
			<< "The program will keep running, but log info will not be written.\n";
		return;
	}
	fs << text;
	fs.close();
}

#endif // !OTHER_UTILITY_FUNCTIONS_H
