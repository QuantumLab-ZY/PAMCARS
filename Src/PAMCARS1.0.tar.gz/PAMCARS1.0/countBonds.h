/**********************************************************************
countBonds.h - Count chemical bond related data in crystals.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/
#ifndef COUNTBONDS_H
#define COUNTBONDS_H

#include <vector>
#include <string>
#include "readOptions.h"
#include "structure.h"
#include "vectorOperations.h"
#include "utilityFunctions.h"

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/stat.h>
#endif

void cartesianCoordinatesOfPeriodicAtoms(const lattVec& latticeVectors, const NVECTOR& atomSite, std::vector<NVECTOR>& periodicAtoms, const int& periodicalRange);

double bondingPairDistance(const std::vector<std::pair<std::string, int>>& components, std::vector<std::pair<std::pair<std::string, std::string>, double>> bondingPair, const int& element1, const int& element2);

bool checkMinDistanceOfAtoms(const readOptions& options, const int& periodicalRange, const crystalInfo& crystal, const int& element1, const int& num1, const int& element2, const int& num2);

double calMinDistance(const int& periodicalRange, const crystalInfo& crystal, const int& element1, const int& num1, const int& element2, const int& num2);

int countChemicalBonds(const crystalInfo& crystal, const readOptions& options, const std::vector<std::pair<std::pair<std::string, std::string>, double>>& atomPairs);

bool checkNumOfSharedVertexes(const crystalInfo& crystal, const readOptions& iterationOptions);

bool checkCoordinationNumber(const crystalInfo& crystal, const readOptions& iterationOptions);

bool checkMinIADForCrystal(const readOptions& iterationOptions, const crystalInfo& crystal);

bool checkMinIADForCrystal(const readOptions& iterationOptions, const crystalInfo& crystal, const std::string& atomicSymbol);

bool checkMaxNumOfAtomsOnPolyhedron(const crystalInfo& crystal, const readOptions& iterationOptions);

#endif