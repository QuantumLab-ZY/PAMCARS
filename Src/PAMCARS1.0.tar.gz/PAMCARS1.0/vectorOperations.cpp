/**********************************************************************
vectorOperations.cpp - A custom class for 3-D vector operations.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/


#include <vector>
#include <math.h>
#include "vectorOperations.h"

using namespace std;

NVECTOR operator+(const NVECTOR& a,const NVECTOR& b){
    NVECTOR c;
    c.x=a.x+b.x;
    c.y=a.y+b.y;
    c.z=a.z+b.z;
    return c;
}

NVECTOR operator-(const NVECTOR& a,const NVECTOR& b){
    NVECTOR c;
    c.x=a.x-b.x;
    c.y=a.y-b.y;
    c.z=a.z-b.z;
    return c;
}

NVECTOR operator*(const int& a, const NVECTOR& b){
	NVECTOR c;
	c.x = a * b.x;
	c.y = a * b.y;
	c.z = a * b.z;
	return c;
}

NVECTOR operator*(const double& a, const NVECTOR& b){
	NVECTOR c;
	c.x = a * b.x;
	c.y = a * b.y;
	c.z = a * b.z;
	return c;
}

double dot(const NVECTOR& a,const NVECTOR& b){
    return(a.x*b.x+a.y*b.y+a.z*b.z);
}

NVECTOR crossdot(const NVECTOR& a,const NVECTOR& b){
    NVECTOR c;
    c.x=a.y*b.z-a.z*b.y;
    c.y=a.z*b.x-a.x*b.z;
    c.z=a.x*b.y-a.y*b.x;
    return c;
}

double vec_norm(const NVECTOR& a){
    return(sqrt(dot(a,a)));
}

double angle_vec(const NVECTOR& a,const NVECTOR& b){
    double temp=dot(a,b)/(vec_norm(a)*vec_norm(b));
    return acos(temp);//The unit is radius
}

double Ndistance(const NVECTOR& a,const NVECTOR& b){
	NVECTOR c = a - b;
    return vec_norm(c);
}

double triple_product(const NVECTOR& a,const NVECTOR& b,const NVECTOR& c){
    return dot(a,crossdot(b,c));
}
