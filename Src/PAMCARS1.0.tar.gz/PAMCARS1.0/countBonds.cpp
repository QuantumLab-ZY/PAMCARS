/**********************************************************************
countBonds.cpp - Count chemical bond related data in crystals.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/
#include "readOptions.h"
#include "structure.h"
#include "vectorOperations.h"
#include "utilityFunctions.h"
#include "otherUtilityFunctions.h"
#include "countBonds.h"

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/stat.h>
#endif

using namespace std;


double bondingPairDistance(const vector<pair<string, int>>& components, vector<pair<pair<string, string>, double>> bondingPair, const int& element1, const int& element2) {
	for (int i = 0; i < bondingPair.size(); ++i) {
		if ((bondingPair[i].first.first == components[element1].first) && (bondingPair[i].first.second == components[element2].first)) {
			return bondingPair[i].second;
		}
		else if ((bondingPair[i].first.first == components[element2].first) && (bondingPair[i].first.second == components[element1].first)) {
			return bondingPair[i].second;
		}
		else
			continue;
	}
	//If they are not a bonded atom pair, return a negative value.
	return -10.0;
}

bool checkMinDistanceOfAtoms(const readOptions& options, const int& periodicalRange, const crystalInfo& crystal, const int& element1, const int& num1, const int& element2, const int& num2)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = options.get_minDistanceOfAtoms();
	double defaultMinDistanceOfAtoms = options.get_defaultMinDistanceOfAtoms();
	//
	double minDistance = calMinDistance(periodicalRange, crystal, element1, num1, element2, num2);
	//
	for (int i = 0; i < minDistanceOfAtoms.size(); ++i) {
		if (minDistanceOfAtoms[i].first.first == components[element1].first && minDistanceOfAtoms[i].first.second == components[element2].first) {
			if (minDistance < minDistanceOfAtoms[i].second) {
				return false;
			}
			else
			{
				return true;
			}
		}//case1
		if (minDistanceOfAtoms[i].first.first == components[element2].first && minDistanceOfAtoms[i].first.second == components[element1].first) {
			if (minDistance < minDistanceOfAtoms[i].second) {
				return false;
			}
			else
			{
				return true;
			}
		}//case2
	}//i
	//If there is no match
	if (minDistance < defaultMinDistanceOfAtoms) {
		return false;
	}
	else
	{
		return true;
	}
}

double calMinDistance(const int& periodicalRange, const crystalInfo& crystal, const int& element1, const int& num1, const int& element2, const int& num2)
{
	lattVec latticeVectors = crystal.get_latticeVectors();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	//
	vector<NVECTOR> periodicAtoms;
	cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element2][num2], periodicAtoms, periodicalRange);
	//
	double min;
	if (element1 == element2 && num1 == num2)
	{
		min = Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[1]);
	}
	else
	{
		min = Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[0]);
	}
	//
	for (int i = 1; i < periodicAtoms.size(); ++i) {
		if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[i]) < min)
		{
			min = Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[i]);
		}
	}
	//
	return min;
}

int countChemicalBonds(const crystalInfo& crystal, const readOptions& options, const vector<pair<pair<string, string>, double>>& atomPairs)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = options.get_minDistanceOfAtoms();
	int periodicalRange = options.get_periodicalRange();
	//
	int totalNumberOfBonds = 0;
	//
	for (int element1 = 0; element1 < components.size(); ++element1) {
		//
		for (int element2 = element1; element2 < components.size(); ++element2) {
			//
			for (int num1 = 0; num1 < components[element1].second; ++num1) {
				//
				for (int num2 = (element1 == element2 ? num1 : 0); num2 < components[element2].second; ++num2) {
					//Find periodic atomic coordinates in the range of "periodicRange".
					//The atom in the unit cell is stored in periodicAtoms[0].
					vector<NVECTOR> periodicAtoms;
					cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element2][num2], periodicAtoms, periodicalRange);

					for (int n = 0; n < periodicAtoms.size(); ++n)
					{
						if (n == 0)
						{
							//Skip the coordinates of the same atom.
							if (element1 == element2 && num1 == num2)
							{
								continue;
							}
						}
						//
						if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms[n])
							< bondingPairDistance(components, atomPairs, element1, element2)) {
							totalNumberOfBonds += 1;
						}
					}//n					
				}//num2
			}//num1
		}//element2
	}//element1
	return totalNumberOfBonds;
}

void cartesianCoordinatesOfPeriodicAtoms(const lattVec& latticeVectors, const NVECTOR& atomSite, vector<NVECTOR>& periodicAtoms, const int& periodicalRange)
{
	//periodicAtoms[0] stores the coordinate of the original site
	periodicAtoms.push_back(atomSite);
	//
	for (int i = -periodicalRange; i <= periodicalRange; ++i)
	{
		for (int j = -periodicalRange; j <= periodicalRange; ++j)
		{
			for (int k = -periodicalRange; k <= periodicalRange; ++k)
			{
				if (i == 0 && j == 0 && k == 0)
				{
					continue;
				}
				//atomSite + i*a + j*b + k*c
				periodicAtoms.push_back(atomSite + i*latticeVectors.a[0] + j*latticeVectors.a[1] + k*latticeVectors.a[2]);
			}//k
		}//j
	}//i
}

int getElementNum(const vector<pair<string, int>>& components, const string& elementName) 
{
	for (int element = 0; element < components.size(); ++element)
	{
		if (components[element].first == elementName)
		{
			return element;
		}
	}
	return -1;
}

bool checkCoordinationNumber(const crystalInfo& crystal, const readOptions& iterationOptions)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	vector<pair<pair<string, string>, double>> atomPairs;
	auto tempBondingPairs = iterationOptions.get_bondingPairs();
	for (size_t i = 0; i < tempBondingPairs.size(); i++)
	{
		for (size_t j = 0; j < tempBondingPairs[i].size(); j++)
		{
			atomPairs.push_back(tempBondingPairs[i][j]);
		}
	}
	vector<pair<string, int>> maxCoordinationNum = iterationOptions.get_maxCoordinationNum();
	//
	for (size_t i = 0; i < maxCoordinationNum.size(); i++)
	{
		int element = getElementNum(components, maxCoordinationNum[i].first);
		if (element == -1)
		{
			continue;
		}
		for (size_t num = 0; num < components[element].second; num++)
		{
			int coordinationNum = 0;
			for (size_t element1 = 0; element1 < components.size(); element1++)
			{
				for (size_t num1 = 0; num1 < components[element1].second; num1++)
				{
					vector<NVECTOR> periodicAtoms;
					cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element1][num1], periodicAtoms, periodicalRange);

					for (int n = 0; n < periodicAtoms.size(); ++n)
					{
						//Skip the coordinates of the same atom.
						if (n == 0)
						{
							if (element1 == element && num1 == num)
							{
								continue;
							}
						}
						//
						if (Ndistance(cartesianCoordinates[element][num], periodicAtoms[n])
							< bondingPairDistance(components, atomPairs, element, element1)) 
						{
							coordinationNum += 1;
						}
					}//n
				}//num1
			}//element1
			if (coordinationNum > maxCoordinationNum[i].second)
			{
				return false;
			}
		}//num
	}//i
	return true;
}

bool checkNumOfSharedVertexes(const crystalInfo& crystal, const readOptions& iterationOptions)
{
	vector<pair<pair<string, string>, int>> maxNumOfSharedVertexes = iterationOptions.get_maxNumOfSharedVertexes();
	vector<pair<pair<string, string>, double>> atomPairs;
	auto tempBondingPairs = iterationOptions.get_bondingPairs();
	for (size_t i = 0; i < tempBondingPairs.size(); i++)
	{
		for (size_t j = 0; j < tempBondingPairs[i].size(); j++)
		{
			atomPairs.push_back(tempBondingPairs[i][j]);
		}
	}
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	const double overlap = 1.0e-3;
	//
	for (size_t i = 0; i < maxNumOfSharedVertexes.size(); i++)
	{
		int element1 = getElementNum(components, maxNumOfSharedVertexes[i].first.first);
		int element3 = getElementNum(components, maxNumOfSharedVertexes[i].first.second);
		if (element1 == -1 || element3 == -1)
		{
			continue;
		}
		for (size_t num1 = 0; num1 < components[element1].second; num1++)
		{
			for (size_t num3 = (element1 == element3 ? num1 : 0); num3 < components[element3].second; num3++)
			{
				vector<NVECTOR> periodicAtoms3;
				cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element3][num3], periodicAtoms3, periodicalRange);
				for (int m = 0; m < periodicAtoms3.size(); ++m)
				{
					int numOfSharedVertexes = 0;
					if (m == 0)
					{
						//Skip the coordinates of the same atom.
						if (element1 == element3 && num1 == num3)
						{
							continue;
						}
					}
					//
					for (size_t element2 = 0; element2 < components.size(); element2++)
					{
						for (size_t num2 = 0; num2 < components[element2].second; num2++)
						{
							vector<NVECTOR> periodicAtoms2;
							cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[element2][num2], periodicAtoms2, periodicalRange);
							for (int n = 0; n < periodicAtoms2.size(); ++n)
							{
								if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms2[n]) < overlap ||
									Ndistance(periodicAtoms3[m], periodicAtoms2[n]) < overlap)
								{
									//This "shared vertex" is actually periodicAtoms3[m] or (element1, num1), and is not really a shared vertex.
									continue;
								}
								if (Ndistance(cartesianCoordinates[element1][num1], periodicAtoms2[n]) < bondingPairDistance(components, atomPairs, element1, element2) &&
									Ndistance(periodicAtoms3[m], periodicAtoms2[n]) < bondingPairDistance(components, atomPairs, element3, element2))
								{
									numOfSharedVertexes += 1;
								}
							}//n
						}//num2
					}//element2
					if (numOfSharedVertexes > maxNumOfSharedVertexes[i].second)
					{
						return false;
					}
				}//m				
			}//num3
		}//num1
	}//i
	return true;
}

bool checkMinIADForCrystal(const readOptions& iterationOptions, const crystalInfo& crystal)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	//
	for (int element1 = 0; element1 < components.size(); ++element1) {
		//
		for (int element2 = element1; element2 < components.size(); ++element2) {
			//
			for (int num1 = 0; num1 < components[element1].second; ++num1) {
				//
				for (int num2 = 0; num2 < components[element2].second; ++num2) {
					//
					if (!checkMinDistanceOfAtoms(iterationOptions, periodicalRange, crystal, element1, num1, element2, num2))
					{
						return false;
					}//checkMinDistanceOfAtoms
				}//num2
			}//num1
		}//element2
	}//element1
	return true;
}

bool checkMinIADForCrystal(const readOptions& iterationOptions, const crystalInfo& crystal, const string& atomicSymbol)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	//
	int element2 = getElementNum(components, atomicSymbol);
	int num2 = components[element2].second - 1;
	for (int element1 = 0; element1 < components.size(); ++element1) {
		for (int num1 = 0; num1 < components[element1].second; ++num1) {
			if (!checkMinDistanceOfAtoms(iterationOptions, periodicalRange, crystal, element1, num1, element2, num2))
			{
				return false;
			}
		}//num1
	}//element1
	return true;
}

bool checkMaxNumOfAtomsOnPolyhedron(const crystalInfo& crystal, const readOptions& iterationOptions)
{
	vector<pair<string, int>> components = crystal.get_components();
	atom cartesianCoordinates = crystal.get_cartesianCoordinates();
	lattVec latticeVectors = crystal.get_latticeVectors();
	vector<pair<pair<string, string>, double>> minDistanceOfAtoms = iterationOptions.get_minDistanceOfAtoms();
	int periodicalRange = iterationOptions.get_periodicalRange();
	vector<pair<pair<string, string>, double>> atomPairs;
	auto tempBondingPairs = iterationOptions.get_bondingPairs();
	for (size_t i = 0; i < tempBondingPairs.size(); i++)
	{
		for (size_t j = 0; j < tempBondingPairs[i].size(); j++)
		{
			atomPairs.push_back(tempBondingPairs[i][j]);
		}
	}
	auto maxNumOfAtomsOnPolyhedron = iterationOptions.get_maxNumOfAtomsOnPolyhedron();
	//
	for (size_t i = 0; i < maxNumOfAtomsOnPolyhedron.size(); i++)
	{
		int centralAtom = getElementNum(components, maxNumOfAtomsOnPolyhedron[i].first);
		if (centralAtom == -1)
		{
			continue;
		}
		for (size_t num = 0; num < components[centralAtom].second; num++)
		{
			for (size_t j = 0; j < maxNumOfAtomsOnPolyhedron[i].second.size(); j++)
			{
				int coordinationAtom = getElementNum(components, maxNumOfAtomsOnPolyhedron[i].second[j].first);
				if (coordinationAtom == -1)
				{
					continue;
				}
				//Calculate the coordination number between coordinationAtom_num1 and centralAtom
				int coordinationNum = 0;
				for (size_t num1 = 0; num1 < components[coordinationAtom].second; num1++)//coordinationAtom_num1
				{
					vector<NVECTOR> periodicAtoms;
					cartesianCoordinatesOfPeriodicAtoms(latticeVectors, cartesianCoordinates[coordinationAtom][num1], periodicAtoms, periodicalRange);

					for (int n = 0; n < periodicAtoms.size(); ++n)
					{
						//Skip the coordinates of the same atom.
						if (n == 0)
						{
							if (centralAtom == coordinationAtom && num1 == num)
							{
								continue;
							}
						}
						//
						if (Ndistance(cartesianCoordinates[centralAtom][num], periodicAtoms[n])
							< bondingPairDistance(components, atomPairs, coordinationAtom, centralAtom))
						{
							coordinationNum += 1;
						}
					}//n
				}//num1
				if (coordinationNum > maxNumOfAtomsOnPolyhedron[i].second[j].second)
				{
					return false;
				}
			}//j
		}//num
	}//i
	return true;
}