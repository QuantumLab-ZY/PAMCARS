/**********************************************************************
soft_info.h - Print the logo of the program.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/
#ifndef SOFT_INFO_H
#define SOFT_INFO_H
#include <iostream>
#include <sstream>

static std::string softInfo()
{
	std::stringstream ss;
	ss  << "\n" << "**************************************************************************************"
		<< "\n" << "*                                                                                    *"
		<< "\n" << "*      $$$$$$$\\   $$$$$$\\  $$\\      $$\\  $$$$$$\\   $$$$$$\\  $$$$$$$\\   $$$$$$\\       *"
		<< "\n" << "*      $$  __$$\\ $$  __$$\\ $$$\\    $$$ |$$  __$$\\ $$  __$$\\ $$  __$$\\ $$  __$$\\      *"
		<< "\n" << "*      $$ |  $$ |$$ /  $$ |$$$$\\  $$$$ |$$ /  \\__|$$ /  $$ |$$ |  $$ |$$ /  \\__|     *"
		<< "\n" << "*      $$$$$$$  |$$$$$$$$ |$$\\$$\\$$ $$ |$$ |      $$$$$$$$ |$$$$$$$  |\\$$$$$$\\       *"
		<< "\n" << "*      $$  ____/ $$  __$$ |$$ \\$$$  $$ |$$ |      $$  __$$ |$$  __$$<  \\____$$\\      *"
		<< "\n" << "*      $$ |      $$ |  $$ |$$ |\\$  /$$ |$$ |  $$\\ $$ |  $$ |$$ |  $$ |$$\\   $$ |     *"
		<< "\n" << "*      $$ |      $$ |  $$ |$$ | \\_/ $$ |\\$$$$$$  |$$ |  $$ |$$ |  $$ |\\$$$$$$  |     *"
		<< "\n" << "*      \\__|      \\__|  \\__|\\__|     \\__| \\______/ \\__|  \\__|\\__|  \\__| \\______/      *"
		<< "\n" << "*                                                                                    *"
		<< "\n" << "*          Author: Yang Zhong        E-mail: zhongyang@mail.nankai.edu.cn            *"
		<< "\n" << "**************************************************************************************" << "\n";
	return ss.str();
}


#endif
