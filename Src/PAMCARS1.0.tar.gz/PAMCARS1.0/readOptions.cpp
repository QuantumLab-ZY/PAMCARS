/**********************************************************************
readOptions.h - Read parameters in Iterations.in
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/


#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include "utilityFunctions.h"
#include "otherUtilityFunctions.h"
#include "readOptions.h"
//
using namespace std;

readOptions::readOptions() :
	bondingPairs(vector<vector<pair<pair<string, string>, double>>>()),
	minDistanceOfAtoms(vector<pair<pair<string, string>, double>>()),
	m_optionsAreValid(true),
	m_filename(""),
	defaultMinDistanceOfAtoms(1.0),
	periodicalRange(1),
	numOfIterations(vector<int>()),
	//
	delta_a(0.0),
	delta_b(0.0),
	delta_c(0.0),
	delta_Alpha(0.0),
	delta_Beta(0.0),
	delta_Gamma(0.0),
	maxDisplacementOfAtoms(vector<pair<string, double>>()),
	defaultMaxDisplacementOfAtoms(0.5),
	maxNumOfSharedVertexes(vector<pair<pair<string, string>, int>>()),
	maxCoordinationNum(vector<pair<string, int>>()),
	numOfTrialCrystals(0),
	sizeOfTheSetsOfIterationStartCriteria(0),
	maxAttemptsToGenerateInitialCrystal(1),
	skipIfTheSetOfIterationStartCriteriaIsEmpty(false),
	maxNumOfAtomsOnPolyhedron(std::vector<std::pair<std::string, std::vector<pair<std::string, int>>>>()),
	useIterationStartCriteria(false)
{
}

readOptions::readOptions(const readOptions& s){
	bondingPairs = s.bondingPairs;
	minDistanceOfAtoms = s.minDistanceOfAtoms;
	defaultMinDistanceOfAtoms = s.defaultMinDistanceOfAtoms;
	m_optionsAreValid = s.m_optionsAreValid;
	m_filename = s.m_filename;
	periodicalRange = s.periodicalRange;
	numOfIterations = s.numOfIterations;
	//
	delta_a = s.delta_a;
	delta_b = s.delta_b;
	delta_c = s.delta_c;
	delta_Alpha = s.delta_Alpha;
	delta_Beta = s.delta_Beta;
	delta_Gamma = s.delta_Gamma;
	maxDisplacementOfAtoms = s.maxDisplacementOfAtoms;
	defaultMaxDisplacementOfAtoms = s.defaultMaxDisplacementOfAtoms;
	maxNumOfSharedVertexes = s.maxNumOfSharedVertexes;
	maxCoordinationNum = s.maxCoordinationNum;
	numOfTrialCrystals = s.numOfTrialCrystals;
	sizeOfTheSetsOfIterationStartCriteria = s.sizeOfTheSetsOfIterationStartCriteria;
	maxAttemptsToGenerateInitialCrystal = s.maxAttemptsToGenerateInitialCrystal;
	skipIfTheSetOfIterationStartCriteriaIsEmpty = s.skipIfTheSetOfIterationStartCriteriaIsEmpty;
	maxNumOfAtomsOnPolyhedron = s.maxNumOfAtomsOnPolyhedron;
	useIterationStartCriteria = s.useIterationStartCriteria;
}


readOptions& readOptions::operator=(const readOptions& s){
    if(this!=&s){
		bondingPairs = s.bondingPairs;
		minDistanceOfAtoms = s.minDistanceOfAtoms;
		defaultMinDistanceOfAtoms = s.defaultMinDistanceOfAtoms;
		m_optionsAreValid = s.m_optionsAreValid;
		m_filename = s.m_filename;
		numOfIterations = s.numOfIterations;
		//
		delta_a = s.delta_a;
		delta_b = s.delta_b;
		delta_c = s.delta_c;
		delta_Alpha = s.delta_Alpha;
		delta_Beta = s.delta_Beta;
		delta_Gamma = s.delta_Gamma;
		maxDisplacementOfAtoms = s.maxDisplacementOfAtoms;
		defaultMaxDisplacementOfAtoms = s.defaultMaxDisplacementOfAtoms;
		maxNumOfSharedVertexes = s.maxNumOfSharedVertexes;
		maxCoordinationNum = s.maxCoordinationNum;
		numOfTrialCrystals = s.numOfTrialCrystals;
		sizeOfTheSetsOfIterationStartCriteria = s.sizeOfTheSetsOfIterationStartCriteria;
		maxAttemptsToGenerateInitialCrystal = s.maxAttemptsToGenerateInitialCrystal;
		skipIfTheSetOfIterationStartCriteriaIsEmpty = s.skipIfTheSetOfIterationStartCriteriaIsEmpty;
		maxNumOfAtomsOnPolyhedron = s.maxNumOfAtomsOnPolyhedron;
		useIterationStartCriteria = s.useIterationStartCriteria;
	}
    return *this;
}



// This function is static
readOptions readOptions::readInput(const string& filename)
{
   readOptions options;
   ifstream f;
   f.open(filename);
   if (!f.is_open()) {
      cerr << "Error: " << filename << " was not opened successfully! Please "
      << "check the permissions and that it exists.\n";
      options.m_optionsAreValid = false;
      return options;
   }
// So that we avoid code duplication, read the contents of this file into
// a string and call the other function. We are assuming that
// the input file is going to be small so this should not cause any
// memory issues...
    string temp;
    string inputStr;
    while (getline(f, temp)) inputStr += (temp + "\n");
    f.close();
    return readOptionsFromCharArray(inputStr.c_str(), filename);
}

// This version of the function reads a character array that contains the full
// input. It is used for the html version of the code
readOptions readOptions::readOptionsFromCharArray(const char* input,
                                                  string filename)
{
    readOptions options;
    options.m_filename = filename;
    string stdstr(input);
    istringstream lines(stdstr);
    string line;
// Read each line and set options
    while (getline(lines, line)) options.interpretLineAndSetOption(line);  
    return options;
}


void readOptions::interpretLineAndSetOption(string line)
{
    // First, trim it
    line = trim(line);
    // If the line is empty, return
    // If the line starts with '#', return
    if (line.size() == 0) return;
    if (line[0] == '#') return;
    // Remove anything to the right of any # in the line - this is a comment
    line = split(line, '#')[0];
    // Separate the option and the value
    vector<string> theSplit = split(line, '=');
    // If this is not two, then there is some kind of error in the line
    if (theSplit.size() != 2) {
       cerr << "In options files, '" << this->m_filename << "', error reading "
       << "the following line: '" << line << "'\n";
	   m_optionsAreValid = false;
       return;
    }
    string option = trim(theSplit[0]);
    string value = trim(theSplit[1]);
    // Now let's figure out what the option is
	if (option == "minDistanceOfAtoms") {
		vector<string> tempSplit = split(value, ',');
		pair<pair<string, string>, double> ssd;
		vector<string> tempString;
		for (int i = 0; i<tempSplit.size(); ++i) {
			tempSplit[i] = trim(tempSplit[i]);
			tempString = split(tempSplit[i], ':');
			ssd.first.first = trim(split(tempString[0], '-')[0]);
			ssd.first.second = trim(split(tempString[0], '-')[1]);
			ssd.second = stod(trim(tempString[1]));
			minDistanceOfAtoms.push_back(ssd);
		}
	}
	//
	else if (option == "bondingPairs") {
		vector<string> bondingPairSplit = split(value, ';');
		for (size_t i = 0; i < bondingPairSplit.size(); i++)
		{
			vector<string> tempSplit = split(bondingPairSplit[i], ',');
			pair<pair<string, string>, double> ssd;
			vector<string> tempString;
			vector<pair<pair<string, string>, double>> tempBondingPair;
			for (int j = 0; j<tempSplit.size(); ++j) {
				tempSplit[j] = trim(tempSplit[j]);
				tempString = split(tempSplit[j], ':');
				ssd.first.first = trim(split(tempString[0], '-')[0]);
				ssd.first.second = trim(split(tempString[0], '-')[1]);
				ssd.second = stod(trim(tempString[1]));
				tempBondingPair.push_back(ssd);
			}//j
			bondingPairs.push_back(tempBondingPair);
		}//i
	}
	//
	else if (option == "maxNumOfSharedVertexes") 
	{
		vector<string> tempSplit = split(value, ',');
		for (int i = 0; i<tempSplit.size(); ++i) 
		{
			pair<pair<string, string>, int> ssi;
			vector<string> tempString;
			tempSplit[i] = trim(tempSplit[i]);
			tempString = split(tempSplit[i], ':');
			ssi.first.first = trim(split(tempString[0], '-')[0]);
			ssi.first.second = trim(split(tempString[0], '-')[1]);
			ssi.second = stoi(trim(tempString[1]));
			maxNumOfSharedVertexes.push_back(ssi);
		}
	}
	//
	else if (option == "maxCoordinationNum") {
		vector<string> maxCoordinationNumSplit = split(value, ',');
		for (size_t i = 0; i < maxCoordinationNumSplit.size(); i++)
		{
			vector<string> maxCoordinationNumSplitSplit = split(maxCoordinationNumSplit[i], ':');
			string elementName = trim(maxCoordinationNumSplitSplit[0]);
			int number = stoi(trim(maxCoordinationNumSplitSplit[1]));
			maxCoordinationNum.push_back(make_pair(elementName, number));
		}
	}
	//
    else if (option == "defaultMinDistanceOfAtoms") {
        defaultMinDistanceOfAtoms = stod(value);
    }
	else if (option == "periodicalRange") {
		periodicalRange = stoi(value);
	}
	else if (option == "numOfIterations") {
		vector<string> tempSplit = split(value, ';');
		for (size_t i = 0; i < tempSplit.size(); i++)
		{
			tempSplit[i] = trim(tempSplit[i]);
			int d = stoi(tempSplit[i]);
			numOfIterations.push_back(d);
		}
	}
	else if (option == "delta_a") {
		delta_a = stod(value);
	}
	else if (option == "delta_b") {
		delta_b = stod(value);
	}
	else if (option == "delta_c") {
		delta_c = stod(value);
	}
	else if (option == "delta_Alpha") {
		delta_Alpha = stod(value);
	}
	else if (option == "delta_Beta") {
		delta_Beta = stod(value);
	}
	else if (option == "delta_Gamma") {
		delta_Gamma = stod(value);
	}
	else if (option == "maxDisplacementOfAtoms") {
		vector<string> tempSplit = split(value, ',');
		pair<string, double> sd;
		for (int i = 0; i<tempSplit.size(); ++i) {
			tempSplit[i] = trim(tempSplit[i]);
			sd.first = trim(split(tempSplit[i], ':')[0]);
			sd.second = stod(trim(split(tempSplit[i], ':')[1]));
			maxDisplacementOfAtoms.push_back(sd);
		}
	}
	else if (option == "defaultMaxDisplacementOfAtoms") {
		defaultMaxDisplacementOfAtoms = stod(value);
	}
	else if (option == "numOfTrialCrystals") {
		numOfTrialCrystals = stoi(value);
	}
	else if (option == "sizeOfTheSetsOfIterationStartCriteria") {
		sizeOfTheSetsOfIterationStartCriteria = stoi(value);
	}
	else if (option == "maxAttemptsToGenerateInitialCrystal") {
		maxAttemptsToGenerateInitialCrystal = stoi(value);
	}
	else if (option == "skipIfTheSetOfIterationStartCriteriaIsEmpty") {
		if (value[0] == 'F' || value[0] == 'f')
			skipIfTheSetOfIterationStartCriteriaIsEmpty = false;
		else if (value[0] == 'T' || value[0] == 't')
			skipIfTheSetOfIterationStartCriteriaIsEmpty = true;
		else {
			cerr << "Error reading 'skipIfTheSetOfIterationStartCriteriaIsEmpty' setting: " << value
				<< "\nValid settings are 'True' or 'False' or 'T' or 'F'\n";
			cerr << "The value will remain the default: false\n";
		}
	}
	else if (option == "maxNumOfAtomsOnPolyhedron")
	{
		vector<string> tempSplit1 = split(value, ';');
		for (size_t i = 0; i < tempSplit1.size(); i++)
		{
			vector<pair<string, int>> tempArray;
			vector<string> tempSplit2 = split(tempSplit1[i], ':');
			string centalAtom = trim(tempSplit2[0]);
			vector<string> tempSplit3 = split(tempSplit2[1], ',');
			for (size_t j = 0; j < tempSplit3.size(); j++)
			{
				vector<string> tempSplit4 = split(tempSplit3[j], '/');
				string atom = trim(tempSplit4[0]);
				int num = stoi(trim(tempSplit4[1]));
				tempArray.push_back(pair<string, int>(atom, num));
			}//j
			maxNumOfAtomsOnPolyhedron.push_back(pair<string, vector<pair<string, int>>>(centalAtom, tempArray));
		}//i
	}
	else if (option == "useIterationStartCriteria")
	{
		if (value[0] == 'F' || value[0] == 'f')
			useIterationStartCriteria = false;
		else if (value[0] == 'T' || value[0] == 't')
			useIterationStartCriteria = true;
		else {
			cerr << "Error reading 'useIterationStartCriteria' setting: " << value
				<< "\nValid settings are 'True' or 'False' or 'T' or 'F'\n";
			cerr << "The value will remain the default: false\n";
		}
	}
    else {
		cout << "The input parameters: '" << option << "' are wrong! Please check the Iterations.in file." << endl;
        exit(0);
    }
}

