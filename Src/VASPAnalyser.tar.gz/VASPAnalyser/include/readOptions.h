/**********************************************************************
readOptions.h - Read parameters in VASPAnalyser.in
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/

#ifndef READOPTION
#define READOPTION
//
#include <string>
#include <vector>

#ifdef _WIN32
#ifndef UNSIGNEDINT
#define UNSIGNEDINT
typedef unsigned int uint;
#endif
#endif

//
class readOptions{
private:
	std::string rootDirectory;
	std::string prefixOfSubdirectory;
	int numOfSubdirectories;
	double toleranceUsingToFindSpg;
	std::string m_filename;
	bool m_optionsAreValid;
public:
    explicit readOptions();
    readOptions& operator=(const readOptions& s);
    readOptions(const readOptions& s);
	static readOptions readInput(const std::string& filename);
    static readOptions readOptionsFromCharArray(const char* input,
		                                        std::string filename = "");
	void interpretLineAndSetOption(std::string line);
    //Getters
	std::string get_rootDirectory() const { return rootDirectory; }
	std::string get_prefixOfSubdirectory() const { return prefixOfSubdirectory; }
	std::string get_filename() const { return m_filename; }
	double get_toleranceUsingToFindSpg() const { return toleranceUsingToFindSpg; }
	int get_numOfSubdirectories() const { return numOfSubdirectories; }	
	// This will return false if the options are invalid
	bool optionsAreValid() const { return m_optionsAreValid; };
	// Setters
	void set_rootDirectory(const std::string& s) { rootDirectory = s; }
	void set_prefixOfSubdirectory(const std::string& s) { prefixOfSubdirectory = s; }	
	void set_filename(const std::string& s) { m_filename = s; }
	void set_toleranceUsingToFindSpg(const double& var) { toleranceUsingToFindSpg = var; }	
	void set_numOfSubdirectories(const int& var) { numOfSubdirectories = var; }
};
#endif
