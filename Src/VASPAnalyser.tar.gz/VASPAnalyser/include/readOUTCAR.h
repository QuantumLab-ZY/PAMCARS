/**********************************************************************
readOUTCAR.h - Read energy in OUTCAR file
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/


#ifndef READOUTCAR_H
#define READOUTCAR_H

#include <fstream>
#include <iostream>
#include <string>
#include <iomanip>
#include "utilityFunctions.h"

static void readEnergyFromOutcar(const std::string& outcarName)
{
	std::ifstream in;
	in.open(outcarName);
	if (!in.is_open()) {
		std::cout << "Error in " << __FUNCTION__ << ": failed to open '"
			<< outcarName << "' for reading!\n";
		return;
	}
	double energy;
	for (std::string str; getline(in, str); )
	{
		std::string line = trim(str);
		if (line == "reached required accuracy - stopping structural energy minimisation")
		{
			throw energy;
		}
		if (contains(line, '='))
		{
			std::vector<std::string> items = split(line, '=');
			std::string firstItem = trim(items[0]);
			if (firstItem == "energy  without entropy")
			{
				std::vector<std::string> tempItems = splitMultipleSpaces(trim(items[1]));
				energy = stod(tempItems[0]);
			}
		}
	}//str
	in.close();
}

#endif // !READOUTCAR_H

