#ifndef INDEXX_H
#define INDEXX_H
#include <iostream>
#define SWAP(a,b) itemp=(a);(a)=(b);(b)=itemp;
#define M 7
#define NSTACK 50

static void indexx(unsigned long n, double arr[], unsigned long indx[])
{
	unsigned long i, indxt, ir = n, itemp, j, k, l = 1;
	int jstack = 0, *istack;
	double a;

	istack = new int[NSTACK + 1];
	for (j = 1; j <= n; j++) indx[j-1] = j;
	for (;;) {
		if (ir - l < M) {
			for (j = l + 1; j <= ir; j++) {
				indxt = indx[j-1];
				a = arr[indxt-1];
				for (i = j - 1; i >= l; i--) {
					if (arr[indx[i-1]-1] <= a) break;
					indx[i] = indx[i-1];
				}
				indx[i] = indxt;
			}
			if (jstack == 0) break;
			ir = istack[(jstack--)-1];
			l = istack[(jstack--)-1];
		}
		else {
			k = (l + ir) >> 1;
			SWAP(indx[k-1], indx[l]);
			if (arr[indx[l-1]-1] > arr[indx[ir-1]-1]) {
				SWAP(indx[l-1], indx[ir-1])
			}
			if (arr[indx[l]-1] > arr[indx[ir-1]-1]) {
				SWAP(indx[l], indx[ir-1])
			}
			if (arr[indx[l-1]-1] > arr[indx[l]-1]) {
				SWAP(indx[l-1], indx[l])
			}
			i = l + 1;
			j = ir;
			indxt = indx[l];
			a = arr[indxt-1];
			for (;;) {
				do i++; while (arr[indx[i-1]-1] < a);
				do j--; while (arr[indx[j-1]-1] > a);
				if (j < i) break;
				SWAP(indx[i-1], indx[j-1])
			}
			indx[l] = indx[j-1];
			indx[j-1] = indxt;
			jstack += 2;
			if (jstack > NSTACK) 
			{ 
				std::cerr << "NSTACK too small in indexx.\n" << std::endl;
				exit(1);
			}
			if (ir - i + 1 >= j - l) {
				istack[jstack-1] = ir;
				istack[jstack - 2] = i;
				ir = j - 1;
			}
			else {
				istack[jstack-1] = j - 1;
				istack[jstack - 2] = l;
				l = i;
			}
		}
	}
	delete[] istack;
}
#undef M
#undef NSTACK
#undef SWAP
#endif