/**********************************************************************
findSpaceGroup.cpp - Using the spglib to determine the spg of a crystal.

Copyright (C) 2015 - 2016 by Patrick S. Avery

This source code is released under the New BSD License, (the "License").

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

***********************************************************************/
#ifndef FINDSPG_H
#define FINDSPG_H

#include "crystal.h"

int findSpaceGroup(Crystal c, double prec = 0.05);

void printLattice(double lat[9]);

#endif // !FINDSPG_H

