/*****************************************************************************
main.cpp - Main function for VASPAnalyser.
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
******************************************************************************/


#include <iostream>
#include <iomanip>
#include <fstream>
#include "crystal.h"
#include "readOptions.h"
#include "findSpg.h"
#include "readOUTCAR.h"
#include "indexx.h"

using namespace std;

int main() 
{
	//Read input parameters
	readOptions options = readOptions::readInput("VASPAnalyser.in");
	string rootDirectory = options.get_rootDirectory();
	string prefixOfSubdirectory = options.get_prefixOfSubdirectory();
	int numOfSubdirectories = options.get_numOfSubdirectories();
	double toleranceUsingToFindSpg = options.get_toleranceUsingToFindSpg();

	//variables
	vector<double> enthalpyOfLegalRelaxedStructures;
	vector<int> spgNumOfLegalPOSCARs;
	vector<int> spgNumOfLegalCONTCARs;
	vector<int> IDOfLegalStructures;
	vector<double> volumeOfLegalPOSCARs;
	vector<double> volumeOfLegalCONTCARs;

	ofstream logFile;
	logFile.open("VASPAnalyser.log");
	if (!logFile.is_open()) {
		cout << "failed to open '" << "VASPAnalyser.log" << "' for writing!\n";
		return 0;
	}
	logFile << "The following structures have not been relaxed successfully:" << endl;
	
	//get energy from OUTCAR
#ifdef _WIN32
	rootDirectory += "\\";
#else
	rootDirectory += "/";
#endif

	for (size_t i = 0; i < numOfSubdirectories; i++)
	{
#ifdef _WIN32
		string subdirectory = prefixOfSubdirectory + "_" + to_string(i+1) + "\\";
#else
		string subdirectory = prefixOfSubdirectory + "_" + to_string(i+1) + "/";
#endif
		string outcarName = rootDirectory + subdirectory + "OUTCAR";
		string poscarName = rootDirectory + subdirectory + "POSCAR";
		string contcarName = rootDirectory + subdirectory + "CONTCAR";

		try
		{
			readEnergyFromOutcar(outcarName);
		    //If there is no "reached required accuracy-stopping structural energy minimisation" in the OUTCAR file, 
			//the structural optimization related to this OUTCAR file is not completed.
			logFile << "The " << i + 1 << "th structure has not been relaxed successfully!" << endl;
		}
		//get energy Successfully
		catch (const double& energy)
		{
			enthalpyOfLegalRelaxedStructures.push_back(energy);
			IDOfLegalStructures.push_back(i + 1);
			//
			try
			{
				Crystal poscar(poscarName.c_str());
				poscar.wrapAtomsToCell();
				//If read POSCAR successfully
				spgNumOfLegalPOSCARs.push_back(findSpaceGroup(poscar, toleranceUsingToFindSpg));
				volumeOfLegalPOSCARs.push_back(poscar.getVolume());
			}
			catch (const readPOSCAREerr&)
			{
				spgNumOfLegalPOSCARs.push_back(-1);
			}
			//
			try
			{
				Crystal contcar(contcarName.c_str());
				contcar.wrapAtomsToCell();
				//If read CONTCAR successfully
				spgNumOfLegalCONTCARs.push_back(findSpaceGroup(contcar, toleranceUsingToFindSpg));
				volumeOfLegalCONTCARs.push_back(contcar.getVolume());
			}
			catch (const readPOSCAREerr&)
			{
				spgNumOfLegalCONTCARs.push_back(-1);
			}
		}
	}//i

	//Close the log file
	logFile.close();
	
	//The i-th minimum energy corresponds to the index number indx[i] in enthalpyOfLegalRelaxedStructures.
	vector<unsigned long> indx(enthalpyOfLegalRelaxedStructures.size());
	//Sort energy
	indexx(enthalpyOfLegalRelaxedStructures.size(), &enthalpyOfLegalRelaxedStructures[0], &indx[0]);

	//Output result to .out file.
	ofstream resultFile;
	resultFile.open("VASPAnalyser.dat");
	if (!resultFile.is_open()) {
		cout << "failed to open '" << "result.dat" << "' for writing!\n";
		return 0;
	}
	stringstream ss;
	ss << "Ranking      ID     OringinalSymmetry     FinalSymmetry      Enthalphy(eV)      OringinalVolume(A^3)      FinalVolume(A^3)" << endl;
	for (int i = 1; i <= indx.size(); i++)
	{
		ss << setw(5) << i + 1 << "     " << setw(5) << IDOfLegalStructures[indx[i]]
			<< "           " << setw(3) << spgNumOfLegalPOSCARs[indx[i]]
			<< "                 " << setw(3) << spgNumOfLegalCONTCARs[indx[i]]
			<< "         " << setw(14) << setprecision(10) << enthalpyOfLegalRelaxedStructures[indx[i]] << "            "
			<< setw(8) << setprecision(6) << volumeOfLegalPOSCARs[indx[i]] << "                " << setw(8) << setprecision(6)
			<< volumeOfLegalCONTCARs[indx[i]] << endl;
	}
	resultFile << ss.str();
	resultFile.close();
}