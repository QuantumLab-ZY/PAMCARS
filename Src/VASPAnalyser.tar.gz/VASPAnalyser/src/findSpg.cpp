
#include <iostream>
#include "findSpg.h"
#include "crystal.h"
extern "C" {
#include "spglib.h"
#include "niggli.h"
}

using namespace std;

int findSpaceGroup(Crystal c, double prec) {
	// Check that the precision is reasonable
	if (prec < 1e-7) {
		std::cerr << "findSpaceGroup called with a precision of "
			<< prec << ". This is likely an error. Resetting prec to "
			<< 0.05 << ".";
		prec = 0.05;
	}

	uint m_spgNumber = 0;
	string m_spgSymbol = "Unknown";
	int num = c.numAtoms();

	vector<vector<double>> latticeVecs = c.getLatticeVecs();

	// if no unit cell or atoms, exit
	if (latticeVecs.size() == 0 || num == 0) {
		std::cerr << "findSpaceGroup( " << prec << " ) called on atom with no cell or atoms!";
		return 0;
	}

	double lattice[3][3];
	for (size_t i = 0; i < 3; i++) {
		for (size_t j = 0; j < 3; j++) {
			lattice[j][i] = latticeVecs.at(i).at(j);
		}
	}

	// Get atom info
	double(*positions)[3] = new double[num][3];
	int* types = new int[num];

	vector<atomStruct> atoms = c.getAtoms();

	for (int i = 0; i < atoms.size(); i++) {
		types[i] = atoms.at(i).atomicNum;
		positions[i][0] = atoms.at(i).x;
		positions[i][1] = atoms.at(i).y;
		positions[i][2] = atoms.at(i).z;
	}

	// find spacegroup
	char symbol[21];
	int spg = spg_get_international(symbol,
		lattice,
		positions,
		types,
		num, prec);

	delete[] positions;
	delete[] types;

	return spg;
}

void printLattice(double lat[9])
{
	for (size_t i = 0; i < 3; i++) {
		for (size_t j = 0; j < 3; j++) {
			cout << lat[i * 3 + j] << "  ";
		}
		cout << "\n";
	}
}