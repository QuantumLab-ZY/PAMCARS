/**********************************************************************
readOptions.cpp - Read parameters in VASPAnalyser.in
Copyright (C) 2020 by Yang Zhong
This source code is released under the New BSD License, (the "License").
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/

#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include "utilityFunctions.h"
#include "readOptions.h"
//
using namespace std;

readOptions::readOptions():
    rootDirectory(""),
	prefixOfSubdirectory(""),
	numOfSubdirectories(0),
	symprec(0.05),
	m_filename("VASPAnalyser.in"),
	m_optionsAreValid(true)
{
}

readOptions::readOptions(const readOptions& s){
	rootDirectory = s.rootDirectory;
	prefixOfSubdirectory = s.prefixOfSubdirectory;
	numOfSubdirectories = s.numOfSubdirectories;
	symprec = s.symprec;
	m_filename = s.m_filename;
	m_optionsAreValid = s.m_optionsAreValid;
}

readOptions& readOptions::operator=(const readOptions& s){
    if(this!=&s){
		rootDirectory = s.rootDirectory;
		prefixOfSubdirectory = s.prefixOfSubdirectory;
		numOfSubdirectories = s.numOfSubdirectories;
		symprec = s.symprec;
		m_filename = s.m_filename;
		m_optionsAreValid = s.m_optionsAreValid;
    }
    return *this;
}

// This function is static
readOptions readOptions::readInput(const string& filename)
{
   readOptions options;
   ifstream f;
   f.open(filename);
   if (!f.is_open()) {
      cerr << "Error: " << filename << " was not opened successfully! Please "
      << "check the permissions and that it exists.\n";
	  options.m_optionsAreValid = false;
      return options;
   }
// So that we avoid code duplication, read the contents of this file into
// a string and call the other function. We are assuming that
// the input file is going to be small so this should not cause any
// memory issues...
    string temp;
    string inputStr;
    while (getline(f, temp)) inputStr += (temp + "\n");
    f.close();
    return readOptionsFromCharArray(inputStr.c_str(), filename);
}

// This version of the function reads a character array that contains the full
// input. It is used for the html version of the code
readOptions readOptions::readOptionsFromCharArray(const char* input,
                                                  string filename)
{
    readOptions options;
    options.m_filename = filename;
    string stdstr(input);
    istringstream lines(stdstr);
    string line;
// First line is a comment, so ignore it
    //getline(lines, line);
// Read each line and set options
    while (getline(lines, line)) options.interpretLineAndSetOption(line);
    return options;
}

vector<uint> createSpgVector(string s)
{
	vector<uint> ret;
	s = trim(s);
	s = removeSpacesAndReturns(s); // important for reading input from html
								   // Split it according to commas
	vector<string> ssplit = split(s, ',');
	for (size_t i = 0; i < ssplit.size(); i++) {
		// Add all individual numbers
		if (isNumber(trim(ssplit[i]))) ret.push_back(stoi(trim(ssplit[i])));
		// Add hyphenated numbers
		else if (contains(ssplit[i], '-')) {
			// Split it
			vector<string> hyphenSplit = split(ssplit[i], '-');
			if (hyphenSplit.size() != 2) {
				cerr << "Error understanding the spacegroups option. Please verify that"
					<< " it is properly formatted with commas and hyphens.\n";
				return ret;
			}
			// Find the first number, and keep adding numbers till we get to the final
			// one
			uint firstNum = stoi(trim(hyphenSplit[0]));
			uint lastNum = stoi(trim(hyphenSplit[1]));
			for (uint i = firstNum; i <= lastNum; i++) ret.push_back(i);
		}
	}
	// Sort the numbers
	sort(ret.begin(), ret.end());
	// Remove duplicates
	ret = removeDuplicates<uint>(ret);
	return ret;
}

void readOptions::interpretLineAndSetOption(string line)
{
    // First, trim it
    line = trim(line);
    // If the line is empty, return
    // If the line starts with '#', return
    if (line.size() == 0) return;
    if (line[0] == '#') return;
    // Remove anything to the right of any # in the line - this is a comment
    line = split(line, '#')[0];
    // Separate the option and the value
    vector<string> theSplit = split(line, '=');
    // If this is not two, then there is some kind of error in the line
    if (theSplit.size() != 2) {
       cerr << "In options files, '" << this->m_filename << "', error reading "
       << "the following line: '" << line << "'\n";
	   m_optionsAreValid = false;
       return;
    }
    string option = trim(theSplit[0]);
    string value = trim(theSplit[1]);
    // Now let's figure out what the option is
    if (option == "rootDirectory") {
        rootDirectory = value;
    }
	else if (option == "prefixOfSubdirectory") {
		prefixOfSubdirectory = value;
	}
	else if (option == "numOfSubdirectories") {
		numOfSubdirectories = stoi(value);
	}
	else if (option == "symprec") {
		symprec = stod(value);
	}
    else {
        cout<<"The input parameters are wrong! Please check the input file."<<endl;
        exit(0);
    }
}

